import { B as EditorSelector, F as BlockOffset, dn as ChildPath, lt as EditorSelection, pn as Path, un as BlockPath, ut as EditorSelectionPoint } from "../_chunks-dts/behavior.types.action.js";
import { PortableTextBlock, PortableTextListBlock, PortableTextObject, PortableTextSpan, PortableTextTextBlock } from "@portabletext/schema";
/**
 * The set of schema member names applicable at the current selection,
 * grouped by category.
 *
 * @beta
 */
type ApplicableSchema = {
  decorators: ReadonlySet<string>;
  annotations: ReadonlySet<string>;
  lists: ReadonlySet<string>;
  styles: ReadonlySet<string>;
  blockObjects: ReadonlySet<string>;
  inlineObjects: ReadonlySet<string>;
};
/**
 * Resolve which schema members are applicable at the current selection. For
 * each named category (decorators, annotations, lists, styles, block objects,
 * inline objects) returns the set of names that the editor allows at the
 * current selection.
 *
 * Categories split by what they apply to:
 *
 * Text-only (decorators, annotations, lists, styles): require text-block
 * content in the selection. A name is applicable when at least one text
 * block the range covers declares it (union). The underlying operations
 * apply per-block, validating each block's sub-schema and skipping blocks
 * that don't declare the type, so the result reflects "will this produce
 * any effect?" semantics. Selection on a void block, or no selection,
 * returns empty sets.
 *
 * Insertion (blockObjects, inlineObjects): the things consumers might
 * insert AT the current selection. The focus block's sub-schema applies
 * even when the selection is on a void block (the question "what can I
 * insert here?" still has an answer). No selection returns empty sets.
 *
 * Useful for gating toolbar buttons, slash-command items, command palettes,
 * keyboard-shortcut hints and other selection-aware UIs.
 *
 * Pair with `getUnionSchema` (from `@portabletext/editor/traversal`) to render a static toolbar whose
 * buttons stay stable across selection moves while gating their enabled
 * state on whether the corresponding name is in the relevant set.
 *
 * Note for React consumers: the returned object is a fresh value on every
 * call, so subscribing via `useEditorSelector` requires a structural
 * compare to avoid re-rendering on every editor tick. Use
 * {@link compareApplicableSchema} as the third argument.
 *
 * @beta
 */
declare const getApplicableSchema: EditorSelector<ApplicableSchema>;
/**
 * Structural comparator for {@link ApplicableSchema} values. Two results
 * compare equal when every category contains the same names (set equality).
 * Pass as the `compare` argument to `useEditorSelector` to keep React
 * subscriptions stable.
 *
 * @beta
 */
declare function compareApplicableSchema(a: ApplicableSchema, b: ApplicableSchema): boolean;
/**
 * @public
 */
declare const getActiveAnnotations: EditorSelector<Array<PortableTextObject>>;
/**
 * @public
 */
declare const getActiveListItem: EditorSelector<PortableTextListBlock['listItem'] | undefined>;
/**
 * @public
 */
declare const getActiveStyle: EditorSelector<PortableTextTextBlock['style']>;
/**
 * Returns the block containing the anchor selection, resolved at any depth.
 *
 * @public
 */
declare const getAnchorBlock: EditorSelector<{
  node: PortableTextBlock;
  path: BlockPath;
} | undefined>;
/**
 * Returns the child (span or inline object) containing the anchor selection,
 * resolved at any depth.
 *
 * @public
 */
declare const getAnchorChild: EditorSelector<{
  node: PortableTextObject | PortableTextSpan;
  path: ChildPath;
} | undefined>;
/**
 * Returns the span containing the anchor selection, resolved at any depth.
 *
 * @public
 */
declare const getAnchorSpan: EditorSelector<{
  node: PortableTextSpan;
  path: ChildPath;
} | undefined>;
/**
 * Returns the text block containing the anchor selection, resolved at any
 * depth.
 *
 * @public
 */
declare const getAnchorTextBlock: EditorSelector<{
  node: PortableTextTextBlock;
  path: BlockPath;
} | undefined>;
/**
 * @public
 */
declare const getBlockOffsets: EditorSelector<{
  start: BlockOffset;
  end: BlockOffset;
} | undefined>;
/**
 * @public
 * Returns the selection of the of the word the caret is placed in.
 * Note: Only returns a word selection if the current selection is collapsed
 */
declare const getCaretWordSelection: EditorSelector<EditorSelection>;
/**
 * Returns the first block at the current container scope.
 *
 * When the focus is inside an editable container (e.g. a code block's line),
 * this returns the first block within that container (the first line). When
 * the focus is at root, or there is no selection, this returns the first
 * block in the document.
 *
 * @public
 */
declare const getFirstBlock: EditorSelector<{
  node: PortableTextBlock;
  path: BlockPath;
} | undefined>;
/**
 * Returns the block containing the focus selection, resolved at any depth.
 *
 * When the focus is inside an editable container (e.g. a code block's line),
 * this returns the innermost block ancestor (the line), not the outer
 * container. When the focus is at root, behavior is unchanged.
 *
 * @public
 */
declare const getFocusBlock: EditorSelector<{
  node: PortableTextBlock;
  path: BlockPath;
} | undefined>;
/**
 * Returns the void block object containing the focus selection, resolved at
 * any depth.
 *
 * Excludes text blocks and editable containers (which have their own children
 * and are not "void"). When the focus is at root, behavior is unchanged.
 *
 * @public
 */
declare const getFocusBlockObject: EditorSelector<{
  node: PortableTextObject;
  path: BlockPath;
} | undefined>;
/**
 * Returns the child (span or inline object) containing the focus selection,
 * resolved at any depth.
 *
 * @public
 */
declare const getFocusChild: EditorSelector<{
  node: PortableTextObject | PortableTextSpan;
  path: ChildPath;
} | undefined>;
/**
 * Returns the inline object containing the focus selection, resolved at any
 * depth.
 *
 * @public
 */
declare const getFocusInlineObject: EditorSelector<{
  node: PortableTextObject;
  path: ChildPath;
} | undefined>;
/**
 * Returns the list block containing the focus selection, resolved at any
 * depth.
 *
 * @public
 */
declare const getFocusListBlock: EditorSelector<{
  node: PortableTextListBlock;
  path: BlockPath;
} | undefined>;
/**
 * Returns the span containing the focus selection, resolved at any depth.
 *
 * @public
 */
declare const getFocusSpan: EditorSelector<{
  node: PortableTextSpan;
  path: ChildPath;
} | undefined>;
/**
 * Returns the text block containing the focus selection, resolved at any depth.
 *
 * When the focus is inside an editable container (e.g. a code block's line),
 * this returns the innermost text block ancestor (the line), not the outer
 * container. When the focus is at root, behavior is unchanged.
 *
 * @public
 */
declare const getFocusTextBlock: EditorSelector<{
  node: PortableTextTextBlock;
  path: BlockPath;
} | undefined>;
/**
 * Returns the smallest top-level-valid fragment of the editor's value
 * that covers the current selection.
 *
 * Starts from {@link getSelectedValue}'s envelope and unwraps it toward
 * the selection's lowest common ancestor, stopping at the deepest level
 * whose siblings are all root-accepted types. Intermediate single-child
 * containers (a single row inside a table, a single cell inside a row)
 * are walked through to look for a deeper unwrap target; an intermediate
 * level with multiple siblings (the lowest common ancestor across two
 * cells in one row) ends the walk and the last root-valid wrapping is
 * returned.
 *
 * Backs every registered clipboard converter, `editor.getFragment()`
 * (which projects to blocks only), and the drag preview pipeline (which
 * uses the paths to find DOM nodes). Exposed for custom converters and
 * any consumer that needs the clipboard-shaped view of the current
 * selection without redundant ancestor envelopes.
 *
 * @public
 */
declare const getFragment: EditorSelector<Array<{
  node: PortableTextBlock;
  path: BlockPath;
}>>;
/**
 * Returns the last block at the current container scope.
 *
 * When the focus is inside an editable container (e.g. a code block's line),
 * this returns the last block within that container (the last line). When
 * the focus is at root, or there is no selection, this returns the last
 * block in the document.
 *
 * @public
 */
declare const getLastBlock: EditorSelector<{
  node: PortableTextBlock;
  path: BlockPath;
} | undefined>;
/**
 * @beta
 */
type MarkState = {
  state: 'unchanged';
  marks: Array<string>;
} | {
  state: 'changed';
  marks: Array<string>;
  previousMarks: Array<string>;
};
/**
 * Given that text is inserted at the current position, what marks should
 * be applied?
 * @beta
 */
declare const getMarkState: EditorSelector<MarkState | undefined>;
/**
 * Returns the block after the selection's end block within the same
 * container scope, if any.
 *
 * Siblings are resolved within the enclosing container (or the document root
 * if the selection is at root level). Never crosses container boundaries.
 *
 * @public
 */
declare const getNextBlock: EditorSelector<{
  node: PortableTextBlock;
  path: BlockPath;
} | undefined>;
/**
 * Returns the inline object after the selection end within the same text
 * block, resolved at any depth.
 *
 * @public
 */
declare const getNextInlineObject: EditorSelector<{
  node: PortableTextObject;
  path: ChildPath;
} | undefined>;
/**
 * Returns all inline objects after the selection end within the same text
 * block, resolved at any depth.
 *
 * @public
 */
declare const getNextInlineObjects: EditorSelector<Array<{
  node: PortableTextObject;
  path: ChildPath;
}>>;
/**
 * Returns the span after the selection end within the same text block,
 * resolved at any depth.
 *
 * @public
 */
declare const getNextSpan: EditorSelector<{
  node: PortableTextSpan;
  path: Path;
} | undefined>;
/**
 * Returns the block before the selection's start block within the same
 * container scope, if any.
 *
 * Siblings are resolved within the enclosing container (or the document root
 * if the selection is at root level). Never crosses container boundaries.
 *
 * @public
 */
declare const getPreviousBlock: EditorSelector<{
  node: PortableTextBlock;
  path: BlockPath;
} | undefined>;
/**
 * Returns the inline object before the selection start within the same text
 * block, resolved at any depth.
 *
 * @public
 */
declare const getPreviousInlineObject: EditorSelector<{
  node: PortableTextObject;
  path: ChildPath;
} | undefined>;
/**
 * Returns all inline objects before the selection start within the same text
 * block, resolved at any depth.
 *
 * @public
 */
declare const getPreviousInlineObjects: EditorSelector<Array<{
  node: PortableTextObject;
  path: ChildPath;
}>>;
/**
 * Returns the span before the selection start within the same text block,
 * resolved at any depth.
 *
 * @public
 */
declare const getPreviousSpan: EditorSelector<{
  node: PortableTextSpan;
  path: Path;
} | undefined>;
/**
 * Returns the root-level blocks the selection covers.
 *
 * Only looks at direct children of the editor. If the selection is inside
 * an editable container, the container itself is returned - not its inner
 * blocks. Containers are preserved whole.
 *
 * Use for block-level operations like `move.block up/down` and
 * drag-and-drop. For "selection as portable text" use `getSelectedValue`;
 * for "text blocks at any depth" use `getSelectedTextBlocks`.
 *
 * @public
 */
declare const getSelectedBlocks: EditorSelector<Array<{
  node: PortableTextBlock;
  path: BlockPath;
}>>;
/**
 * Returns the spans touched by the selection, resolved at any depth.
 *
 * @public
 */
declare const getSelectedSpans: EditorSelector<Array<{
  node: PortableTextSpan;
  path: ChildPath;
}>>;
/**
 * Returns the text blocks touched by the selection, resolved at any depth.
 *
 * Walks the tree between the selection endpoints and returns every text
 * block found, regardless of container nesting. For toolbar state and
 * anywhere that needs "text blocks with text in the selection".
 *
 * @public
 */
declare const getSelectedTextBlocks: EditorSelector<Array<{
  node: PortableTextTextBlock;
  path: Path;
}>>;
/**
 * Returns the portion of the document's value covered by the selection,
 * resolved at any depth.
 *
 * Containers fully inside the selection are preserved verbatim. Containers
 * on the selection boundary are recursed into so only the selected portion
 * of their content is kept. Text blocks on the boundary are span-sliced.
 *
 * The result preserves the full ancestor envelope around the selection. For
 * the clipboard-shaped view that unwraps the envelope toward the selection's
 * lowest common ancestor, see {@link getFragment}.
 *
 * @public
 */
declare const getSelectedValue: EditorSelector<Array<PortableTextBlock>>;
/**
 * @public
 */
declare const getSelection: EditorSelector<EditorSelection>;
/**
 * Returns the block containing the selection's end point, resolved at any
 * depth.
 *
 * @public
 */
declare const getSelectionEndBlock: EditorSelector<{
  node: PortableTextBlock;
  path: BlockPath;
} | undefined>;
/**
 * Returns the child containing the selection's end point, resolved at any
 * depth.
 *
 * @public
 */
declare const getSelectionEndChild: EditorSelector<{
  node: PortableTextSpan | PortableTextObject;
  path: ChildPath;
} | undefined>;
/**
 * @public
 */
declare const getSelectionEndPoint: EditorSelector<EditorSelectionPoint | undefined>;
/**
 * Returns the block containing the selection's start point, resolved at any
 * depth.
 *
 * @public
 */
declare const getSelectionStartBlock: EditorSelector<{
  node: PortableTextBlock;
  path: BlockPath;
} | undefined>;
/**
 * Returns the child containing the selection's start point, resolved at any
 * depth.
 *
 * @public
 */
declare const getSelectionStartChild: EditorSelector<{
  node: PortableTextSpan | PortableTextObject;
  path: ChildPath;
} | undefined>;
/**
 * @public
 */
declare const getSelectionStartPoint: EditorSelector<EditorSelectionPoint | undefined>;
/**
 * @public
 */
declare const getSelectionText: EditorSelector<string>;
/**
 * @public
 */
declare const getBlockTextAfter: EditorSelector<string>;
/**
 * @public
 */
declare const getBlockTextBefore: EditorSelector<string>;
/**
 * @public
 */
declare const getValue: EditorSelector<Array<PortableTextBlock>>;
/**
 * Check whether an annotation is active in the given `snapshot`.
 *
 * @public
 */
declare function isActiveAnnotation(annotation: string, options?: {
  /**
   * Choose whether the annotation has to take up the entire selection in the
   * `snapshot` or if the annotation can be partially selected.
   *
   * Defaults to 'full'
   */
  mode?: 'partial' | 'full';
}): EditorSelector<boolean>;
/**
 * @public
 */
declare function isActiveDecorator(decorator: string): EditorSelector<boolean>;
/**
 * @public
 */
declare function isActiveListItem(listItem: string): EditorSelector<boolean>;
/**
 * @public
 */
declare function isActiveStyle(style: string): EditorSelector<boolean>;
/**
 * @public
 */
declare function isAtTheEndOfBlock(block: {
  node: PortableTextBlock;
  path: BlockPath;
}): EditorSelector<boolean>;
/**
 * @public
 */
declare function isAtTheStartOfBlock(block: {
  node: PortableTextBlock;
  path: BlockPath;
}): EditorSelector<boolean>;
/**
 * Returns true if the supplied selection shares at least one point with the
 * editor's current selection. Resolves at any container depth.
 *
 * Two selections that touch at a single endpoint share that point and are
 * considered overlapping.
 *
 * @public
 */
declare function isOverlappingSelection(selection: EditorSelection): EditorSelector<boolean>;
/**
 * @public
 */
declare function isPointAfterSelection(point: EditorSelectionPoint): EditorSelector<boolean>;
/**
 * @public
 */
declare function isPointBeforeSelection(point: EditorSelectionPoint): EditorSelector<boolean>;
/**
 * @public
 */
declare const isSelectingEntireBlocks: EditorSelector<boolean>;
/**
 * @public
 */
declare const isSelectionCollapsed: EditorSelector<boolean>;
/**
 * @public
 */
declare const isSelectionExpanded: EditorSelector<boolean>;
export { type ApplicableSchema, type MarkState, compareApplicableSchema, getActiveAnnotations, getActiveListItem, getActiveStyle, getAnchorBlock, getAnchorChild, getAnchorSpan, getAnchorTextBlock, getApplicableSchema, getBlockOffsets, getBlockTextAfter, getBlockTextBefore, getCaretWordSelection, getFirstBlock, getFocusBlock, getFocusBlockObject, getFocusChild, getFocusInlineObject, getFocusListBlock, getFocusSpan, getFocusTextBlock, getFragment, getLastBlock, getMarkState, getNextBlock, getNextInlineObject, getNextInlineObjects, getNextSpan, getPreviousBlock, getPreviousInlineObject, getPreviousInlineObjects, getPreviousSpan, getSelectedBlocks, getSelectedSpans, getSelectedTextBlocks, getSelectedValue, getSelection, getSelectionEndBlock, getSelectionEndChild, getSelectionEndPoint, getSelectionStartBlock, getSelectionStartChild, getSelectionStartPoint, getSelectionText, getValue, isActiveAnnotation, isActiveDecorator, isActiveListItem, isActiveStyle, isAtTheEndOfBlock, isAtTheStartOfBlock, isOverlappingSelection, isPointAfterSelection, isPointBeforeSelection, isSelectingEntireBlocks, isSelectionCollapsed, isSelectionExpanded };
//# sourceMappingURL=index.d.ts.map