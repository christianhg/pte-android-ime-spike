import { W as Editor, X as Behavior, Zt as RegistrableNode, q as EditorEmittedEvent } from "../_chunks-dts/behavior.types.action.js";
import React from "react";
/**
 * @beta
 *
 * Plugin component that registers a list of `Behavior`s with the editor.
 *
 * Stabilize the `behaviors` array (a module-level constant or `useMemo`)
 * to avoid a full unregister/re-register cycle on every parent render: a
 * new array reference per render triggers the registration effect to
 * re-run.
 */
declare function BehaviorPlugin(props: {
  behaviors: Array<Behavior>;
}): null;
/**
 * @alpha
 *
 * Plugin component that registers a list of nodes (containers, text
 * blocks, spans, block objects, inline objects) with the editor. Each
 * node is the result of a `defineX` factory.
 *
 * Stabilize the `nodes` array (a module-level constant or `useMemo`)
 * to avoid a full unregister/re-register cycle on every parent
 * render: a new array reference per render triggers the registration
 * effect to re-run.
 */
declare function NodePlugin(props: {
  nodes: Array<RegistrableNode>;
}): null;
/**
 * @beta
 */
declare const EditorRefPlugin: React.ForwardRefExoticComponent<React.RefAttributes<Editor | null>>;
/**
 * @public
 * Listen for events emitted by the editor. Must be used inside `EditorProvider`. Events available include:
 *  - 'blurred'
 *  - 'done loading'
 *  - 'editable'
 *  - 'error'
 *  - 'focused'
 *  - 'invalid value'
 *  - 'loading'
 *  - 'mutation'
 *  - 'patch'
 *  - 'read only'
 *  - 'ready'
 *  - 'selection'
 *  - 'value changed'
 *
 * @example
 * Listen and log events.
 * ```tsx
 * import {EditorProvider} from '@portabletext/editor'
 * import {EventListenerPlugin} from '@portabletext/editor/plugins'
 *
 * function MyComponent() {
 *  return (
 *  <EditorProvider>
 *   <EventListenerPlugin
 *    on={(event) => {
 *     console.log(event)
 *    }
 *   } />
 *   { ... }
 * </EditorProvider>
 *  )
 * }
 * ```
 * @example
 * Handle events when there is a mutation.
 * ```tsx
 * <EventListenerPlugin
 *  on={(event) => {
 *    if (event.type === 'mutation') {
 *      console.log('Value changed:', event.snapshot)
 *    }
 *  }}
 * />
 * ```
 * @group Components
 */
declare function EventListenerPlugin(props: {
  on: (event: EditorEmittedEvent) => void;
}): null;
export { BehaviorPlugin, EditorRefPlugin, EventListenerPlugin, NodePlugin };
//# sourceMappingURL=index.d.ts.map