import { At as Containers, Dt as TraversalSnapshot, Mt as RegisteredContainer, Ot as Node, dt as EditorSelectionPoint, hn as Path, ut as EditorSelection } from "../behavior.types.action-CJHHYRYc.js";
import { PortableTextBlock, PortableTextObject, PortableTextSpan, PortableTextTextBlock, Schema } from "@portabletext/schema";
/**
 * Find an ancestor of the node at a given path that matches a predicate.
 * Does not check the node at the path itself, only its ancestors.
 *
 * `mode: 'lowest'` (default) returns the nearest matching ancestor.
 * `mode: 'highest'` returns the outermost matching ancestor.
 *
 * When `match` is a type predicate, the returned `node` narrows to that type.
 *
 * @public
 */
declare function getAncestor<TMatch extends PortableTextBlock>(snapshot: TraversalSnapshot, path: Path, options: {
  match: (node: PortableTextBlock, path: Path) => node is TMatch;
  mode?: 'lowest' | 'highest';
}): {
  node: TMatch;
  path: Path;
} | undefined;
/**
 * @public
 */
declare function getAncestor(snapshot: TraversalSnapshot, path: Path, options: {
  match: (node: PortableTextBlock, path: Path) => boolean;
  mode?: 'lowest' | 'highest';
}): {
  node: PortableTextBlock;
  path: Path;
} | undefined;
/**
 * Get all ancestors of the node at a given path, from nearest to furthest.
 *
 * For a path like `[{_key:'t1'}, 'rows', {_key:'r1'}, 'cells', {_key:'c1'}]`,
 * the ancestors are (nearest first):
 *
 * ```ts
 * [{_key:'t1'}, 'rows', {_key:'r1'}]
 * [{_key:'t1'}]
 * ```
 *
 * Walks from root to the target in a single pass collecting each ancestor
 * as it goes.
 *
 * Every ancestor is a `PortableTextBlock`: only text blocks and object
 * nodes can contain children.
 *
 * @public
 */
declare function getAncestors(snapshot: TraversalSnapshot, path: Path): Array<{
  node: PortableTextBlock;
  path: Path;
}>;
/**
 * Get the annotation at a given path.
 *
 * Annotations live in `markDefs` on a text block, alongside `children`
 * rather than inside it, so they aren't reachable through `getNode`.
 * `getAnnotation` resolves a path of the shape
 * `[..., {_key: block}, 'markDefs', {_key: annotation}, ...]` to the
 * annotation node on the enclosing text block.
 *
 * @public
 */
declare function getAnnotation(snapshot: TraversalSnapshot, path: Path): {
  node: PortableTextObject;
  path: Path;
} | undefined;
/**
 * Determine if a node at the given path is a block.
 *
 * A node is a block if its parent is not a text block. Top-level nodes
 * (direct children of the editor) are always blocks. Children of text blocks
 * (spans and inline objects) are not blocks. Children of containers are
 * blocks within that container.
 *
 * @public
 */
declare function isBlock(snapshot: TraversalSnapshot, path: Path): boolean;
/**
 * Get the node at the given path if it is a block.
 *
 * Returns the node narrowed to PortableTextBlock, or undefined if the node
 * doesn't exist or is not a block.
 *
 * @public
 */
declare function getBlock(snapshot: TraversalSnapshot, path: Path): {
  node: PortableTextBlock;
  path: Path;
} | undefined;
/**
 * Get the children of a node at a given path.
 *
 * @public
 */
declare function getChildren(snapshot: TraversalSnapshot, path: Path): Array<{
  node: Node;
  path: Path;
}>;
/**
 * Get the registered editable container at a given path.
 *
 * @public
 */
declare function getContainer(snapshot: TraversalSnapshot, path: Path): {
  node: Node;
  path: Path;
} | undefined;
/**
 * Resolve a container node's editable child array.
 *
 * Returns `{children, container}` for a node registered as a container:
 * `children` is the node's editable child array, and `container` is the
 * node's own container registration. Read `container.field.name` for the
 * path segment that reaches `children`, and thread `container` back in as
 * `parent` when descending into them.
 *
 * Returns `undefined` for anything that is not a container: text blocks,
 * spans, leaves, and unregistered objects. It is node-based and resolves
 * in one step with no path re-walk, so recursive descent over containers
 * is linear in nesting depth. The caller seeds the document root from
 * `context.value` itself.
 *
 * @beta
 */
declare function getContainerChildren(containers: Containers, node: Node, parent?: RegisteredContainer): {
  children: Array<Node>;
  container: RegisteredContainer;
} | undefined;
/**
 * Walk up from a path to find the nearest enclosing block.
 *
 * Returns the node at the path if it is a block, otherwise the first ancestor
 * that is a block. Works at any depth — inside a container this returns the
 * container-internal block, not the outer container.
 *
 * With `match`, returns the first enclosing block that also satisfies the
 * predicate. When `match` is a type predicate, the returned `node` narrows
 * to that type.
 *
 * `mode: 'lowest'` (default) returns the innermost enclosing block; the node
 * at the path itself counts. `mode: 'highest'` returns the outermost
 * ancestor that matches, falling back to the node at the path only if no
 * ancestor does.
 *
 * @public
 */
declare function getEnclosingBlock<TMatch extends PortableTextBlock>(snapshot: TraversalSnapshot, path: Path, options: {
  match: (node: PortableTextBlock, path: Path) => node is TMatch;
  mode?: 'lowest' | 'highest';
}): {
  node: TMatch;
  path: Path;
} | undefined;
/**
 * @public
 */
declare function getEnclosingBlock(snapshot: TraversalSnapshot, path: Path, options?: {
  match?: (node: PortableTextBlock, path: Path) => boolean;
  mode?: 'lowest' | 'highest';
}): {
  node: PortableTextBlock;
  path: Path;
} | undefined;
/**
 * Get the first child of a node at a given path.
 *
 * @public
 */
declare function getFirstChild(snapshot: TraversalSnapshot, path: Path): {
  node: Node;
  path: Path;
} | undefined;
/**
 * Get the last child of a node at a given path.
 *
 * @public
 */
declare function getLastChild(snapshot: TraversalSnapshot, path: Path): {
  node: Node;
  path: Path;
} | undefined;
/**
 * Get the deepest leaf node starting from a path, walking toward either the
 * start or end edge. A leaf is any node that has no children according to the
 * traversal context.
 *
 * @public
 */
declare function getLeaf(snapshot: TraversalSnapshot, path: Path, options: {
  edge: 'start' | 'end';
}): {
  node: Node;
  path: Path;
} | undefined;
/**
 * Get the node at a given path.
 *
 * The path can be either keyed (KeyedSegment + field name strings) or
 * indexed (numbers). Keyed segments are resolved by matching `_key`,
 * field name strings name a structural descent into the previous
 * node's children, and numbers are resolved by index.
 *
 * The returned `path` always identifies the returned node: segments
 * are keyed wherever the node has a usable `_key` (numeric indices are
 * converted to `KeyedSegment`s), and stay numeric for nodes
 * normalization has not keyed yet (a `{_key: undefined}` segment would
 * not distinguish keyless siblings). Any trailing segments in the
 * input that point outside the value tree — e.g. an object node's
 * primitive field, or an annotation reached via `'markDefs'` on a text
 * block — are stripped so that
 * `getNode(snapshot, entry.path).node === entry.node`.
 *
 * The walk stops when a string segment names a field that isn't the
 * current node's structural child array. Annotations live in
 * `markDefs` on a text block, alongside `children` rather than inside
 * it, so `getNode` resolves an annotation path to the enclosing text
 * block. Use `getAnnotation` to resolve the annotation itself.
 *
 * @public
 */
declare function getNode(snapshot: TraversalSnapshot, path: Path): {
  node: Node;
  path: Path;
} | undefined;
/**
 * Get the parent of a node at a given path.
 *
 * A parent has children, so it is always a `PortableTextBlock` (text block
 * or object node).
 *
 * When `match` is provided and the parent does not satisfy it, returns
 * `undefined`.
 *
 * @public
 */
declare function getParent<TMatch extends PortableTextBlock>(snapshot: TraversalSnapshot, path: Path, options: {
  match: (node: PortableTextBlock, path: Path) => node is TMatch;
}): {
  node: TMatch;
  path: Path;
} | undefined;
/**
 * @public
 */
declare function getParent(snapshot: TraversalSnapshot, path: Path, options?: {
  match?: (node: PortableTextBlock, path: Path) => boolean;
}): {
  node: PortableTextBlock;
  path: Path;
} | undefined;
/**
 * Return the `Schema` view that applies at a given path.
 *
 * For paths at the root of the document, or for paths where no ancestor is
 * a registered container, returns the top-level schema. For paths inside a
 * container, walks ancestors to find the nearest container and returns the
 * sub-schema derived from its `of` declaration.
 *
 * @public
 */
declare function getPathSubSchema(snapshot: TraversalSnapshot, path: Path): Schema;
/**
 * Get a sibling of the node at a given path.
 *
 * Without `match`, returns the immediate next or previous sibling.
 * With `match`, returns the first sibling in `direction` that satisfies
 * the predicate.
 *
 * When `match` is a type predicate, the returned `node` narrows to that type.
 *
 * @public
 */
declare function getSibling<TMatch extends Node>(snapshot: TraversalSnapshot, path: Path, options: {
  direction: 'next' | 'previous';
  match: (node: Node, path: Path) => node is TMatch;
}): {
  node: TMatch;
  path: Path;
} | undefined;
/**
 * @public
 */
declare function getSibling(snapshot: TraversalSnapshot, path: Path, options: {
  direction: 'next' | 'previous';
  match?: (node: Node, path: Path) => boolean;
}): {
  node: Node;
  path: Path;
} | undefined;
/**
 * Returns:
 *
 * - `-1` if `pointA` is before `pointB`
 * - `0` if `pointA` and `pointB` are equal
 * - `1` if `pointA` is after `pointB`.
 *
 * Compares the two points by document order, resolved at any depth. When
 * the paths are equal, compares offsets.
 *
 * @public
 */
declare function comparePoints(snapshot: TraversalSnapshot, pointA: EditorSelectionPoint, pointB: EditorSelectionPoint): -1 | 0 | 1;
/**
 * Returns true if `ancestor` is equal to `descendant`, or if `descendant`
 * lives anywhere inside `ancestor`'s subtree.
 *
 * @public
 */
declare function pathContains(ancestor: Path, descendant: Path): boolean;
/**
 * Returns true if `range` and the supplied `target` intersect. The target
 * may be a `Path`, an `EditorSelectionPoint`, or another
 * `EditorSelection`.
 *
 * For a `Path` or `EditorSelectionPoint` target, "intersect" means the
 * target lies at or between `range`'s start and end edges (inclusive).
 *
 * For an `EditorSelection` target, "intersect" means either endpoint of
 * `target` lies inside `range`, or `range` strictly encloses `target`.
 *
 * Pass `snapshot.context.selection` as `range` to ask the question against
 * the editor's current selection.
 *
 * Returns `false` when either `range` or `target` is `null`.
 *
 * @public
 */
declare function rangeIntersects(snapshot: TraversalSnapshot, range: EditorSelection, target: Path | EditorSelectionPoint | EditorSelection): boolean;
/**
 * Get the span node at a given path.
 *
 * @public
 */
declare function getSpan(snapshot: TraversalSnapshot, path: Path): {
  node: PortableTextSpan;
  path: Path;
} | undefined;
/**
 * Get the concatenated text content of the node at a given path.
 *
 * @public
 */
declare function getText(snapshot: TraversalSnapshot, path: Path): string | undefined;
/**
 * Get the text block node at a given path.
 *
 * @public
 */
declare function getTextBlock(snapshot: TraversalSnapshot, path: Path): {
  node: PortableTextTextBlock;
  path: Path;
} | undefined;
/**
 * Return a `Schema` that contains every named member declared anywhere
 * in the editor's schema graph that is reachable from a position where text
 * is edited - the root schema merged with the sub-schema of every registered
 * container whose field accepts text blocks, deduped by name. Containers
 * registered in another container's `of` count at any depth, so a table
 * `cell` registered under `row` under `table` contributes its members.
 * When two sources declare the same name, the first one wins: the root
 * schema, then top-level containers in registration order, then nested
 * containers one depth level at a time. Nested containers only add names
 * that no shallower source declares.
 *
 * Useful for rendering a static toolbar whose buttons stay stable across
 * selection moves while still reflecting everything that could plausibly be
 * edited or inserted somewhere.
 *
 * Containers whose field does NOT accept text blocks (e.g. a `table`
 * container whose `rows` field only accepts `row` objects, or a `row`
 * container whose `cells` field only accepts `cell` objects) are
 * **structural**: their immediate `of` types are organizational, not
 * insertable user content. Those structural types are excluded from the
 * union. Their text-block-accepting descendants (e.g. a `cell` that
 * contains a `content` field of `{type: 'block'}`) still contribute when
 * they are registered, either at the top level or nested in the structural
 * container's `of`.
 *
 * Pair with `getPathSubSchema` (or a path-based intersection across a
 * range) to determine which of the union's members are applicable at the
 * current selection.
 *
 * @public
 */
declare function getUnionSchema(schema: Schema, containers: Containers): Schema;
/**
 * Check if a node exists at a given path.
 *
 * @public
 */
declare function hasNode(snapshot: TraversalSnapshot, path: Path): boolean;
/**
 * Determine if a node at the given path is inline.
 *
 * A node is inline if its parent is a text block. This is the inverse of
 * `isBlock`. Top-level nodes are never inline.
 *
 * @public
 */
declare function isInline(snapshot: TraversalSnapshot, path: Path): boolean;
/**
 * Check if a node is a leaf object: an object node that has no editable
 * children (not a container).
 * Returns true for block objects and inline objects that don't have
 * registered editable content (containers).
 *
 * @public
 */
declare function isLeafObject(snapshot: TraversalSnapshot, node: unknown, path: Path): node is PortableTextObject;
/**
 * Check if a node is an object node (not a text block or span).
 *
 * @public
 */
declare function isObject(snapshot: TraversalSnapshot, node: unknown): node is PortableTextObject;
export { comparePoints, getAncestor, getAncestors, getAnnotation, getBlock, getChildren, getContainer, getContainerChildren, getEnclosingBlock, getFirstChild, getLastChild, getLeaf, getNode, getParent, getPathSubSchema, getSibling, getSpan, getText, getTextBlock, getUnionSchema, hasNode, isBlock, isInline, isLeafObject, isObject, pathContains, rangeIntersects };
//# sourceMappingURL=index.d.ts.map