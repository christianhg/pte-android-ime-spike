import { K as Editor, Q as Behavior, Y as EditorEmittedEvent, Zt as RegistrableNode } from "../behavior.types.action-CJHHYRYc.js";
import React from "react";
/**
 * @public
 *
 * Plugin component that registers a list of `Behavior`s with the editor.
 *
 * Stabilize the `behaviors` array (a module-level constant or `useMemo`)
 * to avoid a full unregister/re-register cycle on every parent render: a
 * new array reference per render triggers the registration effect to
 * re-run.
 */
declare function BehaviorPlugin(props: {
  behaviors: Array<Behavior>;
}): null;
/**
 * @public
 *
 * Plugin component that registers a list of nodes (containers, text
 * blocks, spans, block objects, inline objects, decorators, annotations)
 * with the editor. Each node is the result of a `defineX` factory.
 *
 * Stabilize the `nodes` array (a module-level constant or `useMemo`)
 * to avoid a full unregister/re-register cycle on every parent
 * render: a new array reference per render triggers the registration
 * effect to re-run.
 */
declare function NodePlugin(props: {
  nodes: Array<RegistrableNode>;
}): null;
/**
 * @public
 */
declare const EditorRefPlugin: React.ForwardRefExoticComponent<React.RefAttributes<Editor | null>>;
/**
 * @public
 * Listen for events emitted by the editor. Must be used inside `EditorProvider`. Events available include:
 *  - 'blurred'
 *  - 'editable'
 *  - 'focused'
 *  - 'invalid value'
 *  - 'mutation'
 *  - 'patch'
 *  - 'read only'
 *  - 'ready'
 *  - 'selection'
 *  - 'value changed'
 *
 * @example
 * Listen and log events.
 * ```tsx
 * import {defineSchema, EditorProvider} from '@portabletext/editor'
 * import {EventListenerPlugin} from '@portabletext/editor/plugins'
 *
 * const schemaDefinition = defineSchema({})
 *
 * function MyComponent() {
 *  return (
 *  <EditorProvider initialConfig={{schemaDefinition}}>
 *   <EventListenerPlugin
 *    on={(event) => {
 *     console.log(event)
 *    }
 *   } />
 * </EditorProvider>
 *  )
 * }
 * ```
 * @example
 * Handle events when there is a mutation.
 * ```tsx
 * <EventListenerPlugin
 *  on={(event) => {
 *    if (event.type === 'mutation') {
 *      console.log('Value changed:', event.value)
 *    }
 *  }}
 * />
 * ```
 * @group Components
 */
declare function EventListenerPlugin(props: {
  on: (event: EditorEmittedEvent) => void;
}): null;
export { BehaviorPlugin, EditorRefPlugin, EventListenerPlugin, NodePlugin };
//# sourceMappingURL=index.d.ts.map