import React$1, { BaseSyntheticEvent, ClipboardEvent as ClipboardEvent$1, FocusEvent, JSX, PropsWithChildren, ReactElement, ReactNode, TextareaHTMLAttributes } from "react";
import { AnnotationDefinition, AnnotationSchemaType, BaseDefinition, BlockObjectDefinition, BlockObjectSchemaType, DecoratorDefinition, DecoratorSchemaType, FieldDefinition, FieldDefinition as FieldDefinition$1, InlineObjectDefinition, InlineObjectSchemaType, ListDefinition, ListSchemaType, OfDefinition, OfDefinition as OfDefinition$1, PortableTextBlock, PortableTextBlock as PortableTextBlock$1, PortableTextChild, PortableTextChild as PortableTextChild$1, PortableTextObject, PortableTextObject as PortableTextObject$1, PortableTextSpan, PortableTextSpan as PortableTextSpan$1, PortableTextTextBlock, PortableTextTextBlock as PortableTextTextBlock$1, Schema, SchemaDefinition, SchemaDefinition as SchemaDefinition$1, StyleDefinition, StyleSchemaType, TypedObject, defineSchema } from "@portabletext/schema";
import { ActorRefFrom } from "xstate";
import { Patch, Patch as Patch$1 } from "@portabletext/patches";
type MIMEType = `${string}/${string}`;
/**
 * @internal
 */
type PickFromUnion<TUnion, TTagKey extends keyof TUnion, TPickedTags extends TUnion[TTagKey]> = TUnion extends Record<TTagKey, TPickedTags> ? TUnion : never;
type NamespaceEvent<TEvent, TNamespace extends string> = TEvent extends {
  type: infer TEventType;
} ? { [K in keyof TEvent]: K extends 'type' ? `${TNamespace}.${TEventType & string}` : TEvent[K]; } : never;
type StrictExtract<T, U extends T> = U;
type Converter<TMIMEType extends MIMEType = MIMEType> = {
  mimeType: TMIMEType;
  serialize: Serializer<TMIMEType>;
  deserialize: Deserializer<TMIMEType>;
};
type ConverterEvent<TMIMEType extends MIMEType = MIMEType> = {
  type: 'serialize';
  originEvent: 'clipboard.copy' | 'clipboard.cut' | 'drag.dragstart';
} | {
  type: 'serialization.failure';
  mimeType: TMIMEType;
  originEvent: 'clipboard.copy' | 'clipboard.cut' | 'drag.dragstart';
  reason: string;
} | {
  type: 'serialization.success';
  data: string;
  mimeType: TMIMEType;
  originEvent: 'clipboard.copy' | 'clipboard.cut' | 'drag.dragstart';
} | {
  type: 'deserialize';
  data: string;
} | {
  type: 'deserialization.failure';
  mimeType: TMIMEType;
  reason: string;
} | {
  type: 'deserialization.success';
  data: Array<PortableTextBlock>;
  mimeType: TMIMEType;
};
type Serializer<TMIMEType extends MIMEType> = ({ snapshot, event }: {
  snapshot: EditorSnapshot;
  event: PickFromUnion<ConverterEvent<TMIMEType>, 'type', 'serialize'>;
}) => PickFromUnion<ConverterEvent<TMIMEType>, 'type', 'serialization.success' | 'serialization.failure'>;
type Deserializer<TMIMEType extends MIMEType> = ({ snapshot, event }: {
  snapshot: EditorSnapshot;
  event: PickFromUnion<ConverterEvent<TMIMEType>, 'type', 'deserialize'>;
}) => PickFromUnion<ConverterEvent<TMIMEType>, 'type', 'deserialization.success' | 'deserialization.failure'>;
/**
 * A segment in a path that identifies an element by its `_key` property.
 * @public
 */
interface KeyedSegment {
  _key: string;
}
/**
 * A tuple representing a range selection, e.g., `[0, 5]` or `['', 3]`.
 * @public
 */
type IndexTuple = [number | '', number | ''];
/**
 * A single segment in a path. Can be:
 * - A string (property name)
 * - A number (array index)
 * - A KeyedSegment (object with `_key`)
 * - An IndexTuple (range selection)
 * @public
 */
type PathSegment = string | number | KeyedSegment | IndexTuple;
/**
 * A path is an array of path segments that describes a location in a document.
 * @public
 */
type Path = PathSegment[];
/**
 * A path to a block in the value.
 *
 * @public
 */
type BlockPath = Path;
/**
 * A path to an annotation markDef on a block.
 *
 * @public
 */
type AnnotationPath = Path;
/**
 * A path to a child of a text block.
 *
 * @public
 */
type ChildPath = Path;
/**
 * @public
 *
 * A container's render function receives a node and renders an element
 * that wraps its editable children. The render is positional: it fires for
 * nodes of `type` whose parent permits this container at `arrayField`.
 *
 * `node` is `PortableTextObject` because containers cannot register the
 * built-in `'span'` or `'block'` types (those are leaves and text blocks
 * respectively).
 */
type ContainerRenderProps = {
  attributes: Record<string, unknown>;
  children: ReactElement;
  focused: boolean;
  node: PortableTextObject;
  path: Path;
  readOnly: boolean;
  selected: boolean;
  /**
   * Render this position with the engine's default wrapper. Call from
   * inside a custom render to fall back to or wrap the default:
   *
   * ```ts
   * render: (props) => props.renderDefault(props)
   * ```
   *
   * The default is the engine's minimal wrapper. It does not chain
   * back to a globally-registered render: PTE has one user layer plus
   * positional overrides, and the engine default is the canonical
   * fallback at any position.
   */
  renderDefault: (props: ContainerRenderProps) => ReactElement;
};
/**
 * @public
 */
type ContainerRender = (props: ContainerRenderProps) => ReactElement;
/**
 * @public
 *
 * A span's render function. Receives a portable text span node and
 * wraps it. `children` carries the styled text already decorated by
 * the decorator/annotation renders (registered via `defineDecorator`/
 * `defineAnnotation`). Range decorations wrap this render's output
 * from the outside, so they are not part of `children`.
 */
type SpanRenderProps = {
  attributes: Record<string, unknown>;
  children: ReactElement;
  focused: boolean;
  node: PortableTextSpan;
  path: Path;
  readOnly: boolean;
  selected: boolean;
  /**
   * Render this position with the engine's default wrapper.
   * See {@link ContainerRenderProps.renderDefault}.
   */
  renderDefault: (props: SpanRenderProps) => ReactElement;
};
/**
 * @public
 */
type SpanRender = (props: SpanRenderProps) => ReactElement;
/**
 * @public
 *
 * A decorator's render function. Receives the decorator name and
 * wraps the styled text it applies to. Range and selection decorations
 * can split one span into several leaves, so this fires once per
 * decorator on each leaf, not once per span, nested in the span's
 * `marks` order.
 *
 * The render is a plain function call, not a component: do not call
 * hooks in it. When you need hooks, return an element of your own
 * component: `render: (props) => <MyDecorator {...props} />`.
 */
type DecoratorRenderProps = {
  children: ReactElement;
  /**
   * The decorator name, e.g. `'strong'`. A `'*'` render
   * discriminates on this.
   */
  decorator: string;
  focused: boolean;
  /**
   * Path of the span carrying the decorator.
   */
  path: Path;
  readOnly: boolean;
  selected: boolean;
  /**
   * Render this position with the engine's default wrapper.
   * See {@link ContainerRenderProps.renderDefault}. The default is
   * identity: the engine applies no decorator markup of its own.
   */
  renderDefault: (props: DecoratorRenderProps) => ReactElement;
};
/**
 * @public
 */
type DecoratorRender = (props: DecoratorRenderProps) => ReactElement;
/**
 * @public
 *
 * An annotation's render function. Receives the annotation's `markDef`
 * object and wraps the styled text it applies to. The engine anchors
 * the text in a `<span>` outside this render regardless of whether a
 * render is registered; this render's job is the styling wrapper only.
 *
 * The render is a plain function call, not a component: do not call
 * hooks in it. When you need hooks, return an element of your own
 * component: `render: (props) => <MyAnnotation {...props} />`.
 */
type AnnotationRenderProps = {
  /**
   * The annotation's `markDef` object: `{_key, _type, ...fields}`.
   * Named `annotation`, not `node`, because `path` addresses the span
   * leaf carrying the annotation; the markDef itself lives in the block's
   * `markDefs` array.
   */
  annotation: PortableTextObject;
  children: ReactElement;
  focused: boolean;
  path: Path;
  readOnly: boolean;
  selected: boolean;
  /**
   * Render this position with the engine's default wrapper.
   * See {@link ContainerRenderProps.renderDefault}. The default is
   * identity: the engine applies no annotation markup of its own.
   */
  renderDefault: (props: AnnotationRenderProps) => ReactElement;
};
/**
 * @public
 */
type AnnotationRender = (props: AnnotationRenderProps) => ReactElement;
/**
 * @public
 *
 * A block object's render function. Receives a non-editable block-level
 * portable text object. `children` carries an engine-emitted void
 * spacer that the browser uses to anchor the caret next to the
 * element. Dropping `children` makes the caret unable to land on the
 * element.
 */
type BlockObjectRenderProps = {
  attributes: Record<string, unknown>;
  children: ReactElement;
  focused: boolean;
  node: PortableTextObject;
  path: Path;
  readOnly: boolean;
  selected: boolean;
  /**
   * Render this position with the engine's default wrapper.
   * See {@link ContainerRenderProps.renderDefault}.
   */
  renderDefault: (props: BlockObjectRenderProps) => ReactElement;
};
/**
 * @public
 */
type BlockObjectRender = (props: BlockObjectRenderProps) => ReactElement;
/**
 * @public
 *
 * An inline object's render function. Receives a non-editable inline
 * portable text object. `children` carries an engine-emitted void
 * spacer that the browser uses to anchor the caret next to the
 * element. Dropping `children` makes the caret unable to land on the
 * element.
 */
type InlineObjectRenderProps = {
  attributes: Record<string, unknown>;
  children: ReactElement;
  focused: boolean;
  node: PortableTextObject;
  path: Path;
  readOnly: boolean;
  selected: boolean;
  /**
   * Render this position with the engine's default wrapper.
   * See {@link ContainerRenderProps.renderDefault}.
   */
  renderDefault: (props: InlineObjectRenderProps) => ReactElement;
};
/**
 * @public
 */
type InlineObjectRender = (props: InlineObjectRenderProps) => ReactElement;
/**
 * @public
 *
 * A container registration. Identifies a block object `_type` whose value
 * holds editable children in `arrayField`. The optional `of` array carries
 * nested registrations that override how immediate children of this
 * container render at this lexical scope.
 *
 * `of` overrides apply ONE level down only. Children at deeper levels fall
 * through to global registrations.
 *
 * The `kind` field is injected by `defineContainer` and discriminates
 * containers from other registration kinds at runtime.
 */
type Container = {
  kind: 'container';
  type: string;
  arrayField: string;
  /**
   * Outer render. Two modes:
   * - omitted: fall through to global registered render (or engine default)
   * - function: use this render. The function receives a `renderDefault`
   *   prop that returns the engine default when called.
   */
  render?: ContainerRender;
  /**
   * Block-level positional overrides. Inline-content kinds (`Span`,
   * `InlineObject`) belong in `TextBlock.of`, not here.
   */
  of?: ReadonlyArray<Container | TextBlock | BlockObject>;
};
/**
 * @public
 *
 * A text block registration. The text block `_type` is `'block'` at the
 * top level. Positional overrides nested in a container's `of` array can
 * register a different `_type` to render at that lexical scope.
 *
 * `defineTextBlock` opts the text block into the new render pipeline.
 * The consumer's `render` callback owns the outer wrapper entirely: the
 * engine emits `data-pt-*` attributes only, no `pt-*` CSS classes and no
 * legacy `data-block-*` attributes.
 *
 * Span-level rendering - decorator and annotation registrations,
 * `renderPlaceholder`, and range decorations - keeps working. It
 * fires on the spans inside `children` regardless of which text
 * block outer wrapper renders them.
 */
type TextBlock = {
  kind: 'textBlock';
  type: string;
  /**
   * Outer render. Two modes:
   * - omitted: fall through to global registered render (or engine default)
   * - function: use this render. The function receives a `renderDefault`
   *   prop that returns the engine default when called.
   */
  render?: TextBlockRender;
  /**
   * Inline-content positional overrides. A `Span` or `InlineObject`
   * placed here scopes the inline render to this text block (or any
   * text block of this `type` if registered at the top level).
   * `Decorator` and `Annotation` entries scope those renders the
   * same way: the decorator or annotation renders through this entry
   * inside the text block, and through the global registration
   * everywhere else.
   */
  of?: ReadonlyArray<Span | InlineObject | Decorator | Annotation>;
};
/**
 * @public
 *
 * Text block render function. `children` carries the rendered spans -
 * decorator and annotation registrations, `renderPlaceholder`, and
 * range decorations have already fired at the leaf level. The render's
 * job is the outer wrapper element and any block-level composition
 * (style, list-item) the consumer wants.
 */
type TextBlockRenderProps = {
  attributes: Record<string, unknown>;
  children: ReactElement;
  focused: boolean;
  node: PortableTextTextBlock;
  path: Path;
  readOnly: boolean;
  selected: boolean;
  /**
   * Render this position with the engine's default wrapper.
   * See {@link ContainerRenderProps.renderDefault}.
   */
  renderDefault: (props: TextBlockRenderProps) => ReactElement;
};
/**
 * @public
 */
type TextBlockRender = (props: TextBlockRenderProps) => ReactElement;
/**
 * @public
 *
 * A span registration. The span `_type` is `'span'` at the top level.
 * Positional overrides nested in a container's `of` array can register
 * a different `_type` for a span-like inline at that lexical scope
 * (e.g. a `code-span` inside a `code-block`).
 */
type Span = {
  kind: 'span';
  type: string;
  /**
   * Outer render. Two modes:
   * - omitted: fall through to global registered render (or engine default)
   * - function: use this render. The function receives a `renderDefault`
   *   prop that returns the engine default when called.
   */
  render?: SpanRender;
};
/**
 * @public
 *
 * A decorator registration. `type` is a decorator name declared in
 * the schema's `decorators` array, or `'*'` to match every decorator.
 */
type Decorator = {
  kind: 'decorator';
  type: string;
  /**
   * Outer render. Two modes:
   * - omitted: fall through to global registered render (or identity,
   *   the engine default, if no global registration exists)
   * - function: use this render. The function receives a `renderDefault`
   *   prop that returns identity when called.
   */
  render?: DecoratorRender;
};
/**
 * @public
 *
 * An annotation registration. `type` is an annotation `_type` declared
 * in the schema's `annotations` array, or `'*'` to match every
 * annotation type.
 */
type Annotation = {
  kind: 'annotation';
  type: string;
  /**
   * Outer render. Two modes:
   * - omitted: fall through to global registered render (or identity,
   *   the engine default, if no global registration exists)
   * - function: use this render. The function receives a `renderDefault`
   *   prop that returns identity when called.
   */
  render?: AnnotationRender;
};
/**
 * @public
 *
 * A non-editable block-level object registration. Identifies a `_type`
 * whose value renders as a block-level void node (image, embed, etc.).
 */
type BlockObject = {
  kind: 'blockObject';
  type: string;
  /**
   * Outer render. Two modes:
   * - omitted: fall through to global registered render (or engine default)
   * - function: use this render. The function receives a `renderDefault`
   *   prop that returns the engine default when called.
   */
  render?: BlockObjectRender;
};
/**
 * @public
 *
 * A non-editable inline object registration. Identifies a `_type` whose
 * value renders as an inline void node (mention, inline image, etc.).
 */
type InlineObject = {
  kind: 'inlineObject';
  type: string;
  /**
   * Outer render. Two modes:
   * - omitted: fall through to global registered render (or engine default)
   * - function: use this render. The function receives a `renderDefault`
   *   prop that returns the engine default when called.
   */
  render?: InlineObjectRender;
};
/**
 * @public
 *
 * The discriminated union of every registration accepted by
 * `editor.registerNode` and the `<NodePlugin>` component.
 */
type RegistrableNode = Container | TextBlock | Span | BlockObject | InlineObject | Decorator | Annotation;
/**
 * @public
 *
 * Define a container renderer. The returned registration is mounted via
 * the `<NodePlugin>` component at the top level, or nested inside
 * another container's `of` array as a positional override.
 *
 * `type` cannot be `'span'` (use {@link defineSpan}) nor `'block'` (use
 * {@link defineTextBlock}). The text block is not a container.
 *
 * The `node` argument of `render` narrows to a portable text object.
 *
 * @example
 * ```ts
 * defineContainer({
 *   type: 'table',
 *   arrayField: 'rows',
 *   render: ({children}) => (
 *     <table>{children}</table>
 *   ),
 *   of: [
 *     defineContainer({
 *       type: 'row',
 *       arrayField: 'cells',
 *       render: ({children}) => (
 *         <tr>{children}</tr>
 *       ),
 *     }),
 *   ],
 * })
 * ```
 */
declare function defineContainer<const TType extends string>(config: {
  type: TType extends 'span' ? "Error: defineContainer({type: 'span'}) is forbidden -- 'span' is always a span, use defineSpan" : TType extends 'block' ? "Error: defineContainer({type: 'block'}) is forbidden -- 'block' is always a text block, use defineTextBlock" : TType extends '*' ? "Error: defineContainer({type: '*'}) is forbidden -- containers cannot be registered by wildcard" : TType;
  arrayField: string;
  render?: (props: {
    attributes: Record<string, unknown>;
    children: ReactElement;
    focused: boolean;
    node: TType extends 'span' | 'block' ? never : PortableTextObject;
    path: Path;
    readOnly: boolean;
    selected: boolean;
    renderDefault: (props: ContainerRenderProps) => ReactElement;
  }) => ReactElement;
  of?: ReadonlyArray<Container | TextBlock | BlockObject>;
}): Container;
/**
 * @public
 *
 * Define a span renderer. The returned registration is mounted via the
 * `<NodePlugin>` component at the top level, or nested inside a
 * container's `of` array as a positional override.
 *
 * `type` is required even though there is only one top-level span type
 * (`'span'`) today. Keeping `type` required leaves the door open for
 * positional overrides of span-like inlines (e.g. a `code-span` inside
 * a `code-block` container).
 *
 * @example
 * ```ts
 * defineSpan({
 *   type: 'span',
 *   render: ({attributes, children}) => (
 *     <span {...attributes}>{children}</span>
 *   ),
 * })
 * ```
 */
declare function defineSpan<const TType extends string>(config: {
  type: TType extends 'block' ? "Error: defineSpan({type: 'block'}) is forbidden -- 'block' is always a text block, use defineTextBlock" : TType;
  render?: SpanRender;
}): Span;
/**
 * @public
 *
 * Define a decorator renderer for a decorator name declared in the
 * schema's `decorators` array, or `'*'` to match every decorator.
 * The returned registration is mounted via the `<NodePlugin>`
 * component.
 *
 * Decorator names live in a different namespace than node
 * `_type`s, so `type` has no forbidden values here (unlike
 * `defineSpan`/`defineTextBlock`).
 *
 * @example
 * ```ts
 * defineDecorator({
 *   type: 'strong',
 *   render: ({children}) => <strong>{children}</strong>,
 * })
 * ```
 */
declare function defineDecorator(config: {
  type: string;
  render?: DecoratorRender;
}): Decorator;
/**
 * @public
 *
 * Define an annotation renderer for a `_type` declared in the
 * schema's `annotations` array, or `'*'` to match every annotation
 * type. The returned registration is mounted via the `<NodePlugin>`
 * component.
 *
 * Annotation `_type`s live in a different namespace than node
 * `_type`s, so `type` has no forbidden values here (unlike
 * `defineInlineObject`/`defineBlockObject`).
 *
 * @example
 * ```ts
 * defineAnnotation({
 *   type: 'link',
 *   render: ({annotation, children}) => (
 *     <a href={(annotation as {href?: string}).href}>{children}</a>
 *   ),
 * })
 * ```
 */
declare function defineAnnotation(config: {
  type: string;
  render?: AnnotationRender;
}): Annotation;
/**
 * @public
 *
 * Define a non-editable block-level object renderer for a `_type`
 * declared in the schema's `blockObjects` array.
 *
 * The render must always render `children` somewhere inside the outer
 * element. `children` carries an engine-emitted void spacer the browser
 * uses to anchor the caret next to the element. Dropping `children`
 * makes the caret unable to land on the element.
 *
 * @example
 * ```ts
 * defineBlockObject({
 *   type: 'image',
 *   render: ({attributes, children, node}) => (
 *     <div {...attributes}>
 *       {children}
 *       <img src={(node as {src?: string}).src} />
 *     </div>
 *   ),
 * })
 * ```
 */
declare function defineBlockObject<const TType extends string>(config: {
  type: TType extends 'block' ? "Error: defineBlockObject({type: 'block'}) is forbidden -- 'block' is always a text block, use defineTextBlock" : TType extends 'span' ? "Error: defineBlockObject({type: 'span'}) is forbidden -- 'span' is always a span, use defineSpan" : TType;
  render?: BlockObjectRender;
}): BlockObject;
/**
 * @public
 *
 * Define a non-editable inline object renderer for a `_type` declared
 * in the schema's `inlineObjects` array.
 *
 * The render must always render `children` somewhere inside the outer
 * element. `children` carries an engine-emitted void spacer the browser
 * uses to anchor the caret next to the element. Dropping `children`
 * makes the caret unable to land on the element.
 *
 * @example
 * ```ts
 * defineInlineObject({
 *   type: 'mention',
 *   render: ({attributes, children, node}) => (
 *     <span {...attributes}>
 *       {children}
 *       @{(node as {username?: string}).username}
 *     </span>
 *   ),
 * })
 * ```
 */
declare function defineInlineObject<const TType extends string>(config: {
  type: TType extends 'block' ? "Error: defineInlineObject({type: 'block'}) is forbidden -- 'block' is always a text block, use defineTextBlock" : TType extends 'span' ? "Error: defineInlineObject({type: 'span'}) is forbidden -- 'span' is always a span, use defineSpan" : TType;
  render?: InlineObjectRender;
}): InlineObject;
/**
 * @public
 *
 * Define a text block renderer. The returned registration is mounted
 * via the `<NodePlugin>` component, or nested inside a container's
 * `of` array as a positional override.
 *
 * `type` is required even though the top-level text block type is
 * always `'block'`. Keeping `type` required leaves the door open for
 * positional overrides of text-block-like elements (e.g. a `code-line`
 * inside a `code-block` container).
 *
 * @example
 * ```ts
 * defineTextBlock({
 *   type: 'block',
 *   render: ({attributes, children}) => (
 *     <p {...attributes}>{children}</p>
 *   ),
 * })
 * ```
 */
declare function defineTextBlock<const TType extends string>(config: {
  type: TType extends 'span' ? "Error: defineTextBlock({type: 'span'}) is forbidden -- 'span' is always a span, use defineSpan" : TType;
  render?: TextBlockRender;
  of?: ReadonlyArray<Span | InlineObject | Decorator | Annotation>;
}): TextBlock;
/**
 * @internal
 *
 * Resolved span config.
 */
type SpanConfig = {
  span: Span;
};
/**
 * @internal
 *
 * Resolved decorator config.
 */
type DecoratorConfig = {
  decorator: Decorator;
};
/**
 * @internal
 *
 * Resolved annotation config.
 */
type AnnotationConfig = {
  annotation: Annotation;
};
/**
 * @internal
 *
 * Resolved block-object config.
 */
type BlockObjectConfig = {
  blockObject: BlockObject;
};
/**
 * @internal
 *
 * Resolved inline-object config.
 */
type InlineObjectConfig = {
  inlineObject: InlineObject;
};
/**
 * @internal
 *
 * Resolved container config carrying the pre-resolved `field` for the
 * activation position. Dispatch reads pre-resolved data without
 * re-walking the schema.
 */
type ContainerConfig = {
  container: Container;
  field: ChildArrayField;
  of?: ReadonlyArray<ContainerConfig | BlockObjectConfig | TextBlockConfig>;
};
/**
 * @internal
 *
 * Resolved text block config. The optional `of` carries resolved
 * inline-content positional overrides (spans, inline-objects, and
 * per-decorator and per-annotation overrides) for children rendered
 * inside this text block.
 */
type TextBlockConfig = {
  textBlock: TextBlock;
  of?: ReadonlyArray<SpanConfig | InlineObjectConfig | DecoratorConfig | AnnotationConfig>;
};
/**
 * Public view of a registered editable container, surfaced on
 * {@link EditorContext.containers}.
 *
 * Two array properties named `of` live on the same entry with
 * different semantics:
 *
 * - `field.of` is the SCHEMA-DECLARED list of types this container's
 *   child field accepts (from `@portabletext/schema`'s
 *   `OfDefinition`). Tells you what the schema permits as children.
 * - `of` (top-level on `RegisteredContainer`) is the list of
 *   POSITIONAL CHILD REGISTRATIONS - nested
 *   {@link RegisteredContainer} or {@link RegisteredPositional}
 *   entries - that override the global registration when the engine
 *   descends into this parent. Tells you which child renderings are
 *   scoped to this parent.
 *
 * The full container registration (including the render callback)
 * lives on an engine-internal map and is not exposed on the public
 * context.
 *
 * Two top-level entries with the same `_type` cannot coexist - the
 * register handler warns on duplicates. But the SAME `_type`
 * registered in two different parents' `of` arrays is supported as
 * a feature; `resolveContainerAt` walks the positional tree using
 * the path to return the entry that applies at a given position.
 *
 * @public
 */
type RegisteredContainer = {
  kind: 'container';
  type: string;
  field: FieldDefinition & {
    type: 'array';
    of: ReadonlyArray<OfDefinition>;
  };
  of?: ReadonlyArray<RegisteredContainer | RegisteredPositional>;
};
type ChildArrayField = RegisteredContainer['field'];
/**
 * Public view of a registered span, surfaced inside a containing
 * {@link RegisteredContainer}'s `of` array as a positional
 * registration. The render function is engine-internal.
 *
 * @public
 */
type RegisteredSpan = {
  kind: 'span';
  type: string;
};
/**
 * Public view of a registered block object, surfaced inside a
 * containing {@link RegisteredContainer}'s `of` array as a positional
 * registration. The render function is engine-internal.
 *
 * @public
 */
type RegisteredBlockObject = {
  kind: 'blockObject';
  type: string;
};
/**
 * Public view of a registered inline object, surfaced inside a
 * containing {@link RegisteredContainer}'s `of` array as a positional
 * registration. The render function is engine-internal.
 *
 * @public
 */
type RegisteredInlineObject = {
  kind: 'inlineObject';
  type: string;
};
/**
 * Union of non-container positional registrations that may appear in
 * a {@link RegisteredContainer}'s `of` array. Text-block registrations
 * are NOT included here and do not appear on the containers tree.
 *
 * @public
 */
type RegisteredPositional = RegisteredSpan | RegisteredBlockObject | RegisteredInlineObject;
/**
 * Map of registered editable containers carried on `EditorContext`.
 *
 * Keyed by bare block-object `_type` (e.g. `'callout'`, `'table'`).
 * Each entry is a rich {@link RegisteredContainer} carrying its
 * `field` plus any positional `of` registrations.
 *
 * The map preserves positional structure: a `_type` declared inside
 * a parent's `of` array surfaces as a nested entry on that parent's
 * `of`, NOT as a separate top-level entry. Path-driven resolution
 * (see `resolveContainerAt`) reaches positional entries by walking
 * the tree.
 *
 * Top-level entries are global fallbacks: when path-driven descent
 * does not find a positional override, the resolver falls back to the
 * top-level entry for the type if one is registered.
 *
 * @public
 */
type Containers = ReadonlyMap<string, RegisteredContainer>;
/**
 * Engine-internal map carrying the fully-resolved container
 * configurations - including render functions and positional `of`
 * overrides. Lives on `editor.containers` and is consulted by render
 * dispatch and engine-internal helpers.
 *
 * Not exposed on {@link EditorContext}.
 */
type ResolvedContainers = Map<string, ContainerConfig>;
/**
 * @public
 */
type EditorSchema = Schema;
type Node$1 = PortableTextTextBlock | PortableTextObject | PortableTextSpan;
/**
 * Snapshot-shaped input for traversal utilities.
 *
 * Mirrors the shape of `EditorSnapshot`: ambient state lives under
 * `context`, the `blockIndexMap` perf cache sits as a sibling.
 */
type TraversalSnapshot = {
  context: {
    schema: EditorSchema;
    containers: Containers;
    value: Array<Node$1>;
  };
  blockIndexMap: ReadonlyMap<string, number>;
};
/**
 * @public
 * @deprecated Use `useEditor()` instead
 *
 * ```
 * import {useEditor} from '@portabletext/editor'
 *
 * // Get the editor instance
 * const editor = useEditor()
 *
 * // Send events to the editor
 * editor.send(...)
 *
 * // Derive state from the editor
 * const state = useEditorSelector(editor, snapshot => ...)
 * ```
 */
declare class PortableTextEditor {
  /**
   * A lookup table for all the relevant schema types for this portable text type.
   */
  schemaTypes: Schema;
  private editable;
  constructor(config: {
    editable: EditableAPI;
    editorActor: EditorActor;
  });
  setEditable: (editable: EditableAPI) => void;
  /**
   * @deprecated
   * Use built-in selectors or write your own: https://www.portabletext.org/reference/selectors/
   *
   * ```
   * import * as selectors from '@portabletext/editor/selectors'
   * const editor = useEditor()
   * const isActive = useEditorSelector(editor, selectors.getActiveAnnotations)
   * ```
   */
  static activeAnnotations: (editor: PortableTextEditor) => PortableTextObject[];
  /**
   * @deprecated
   * Use built-in selectors or write your own: https://www.portabletext.org/reference/selectors/
   *
   * ```
   * import * as selectors from '@portabletext/editor/selectors'
   * const editor = useEditor()
   * const isActive = useEditorSelector(editor, selectors.isActiveAnnotation(...))
   * ```
   */
  static isAnnotationActive: (editor: PortableTextEditor, annotationType: PortableTextObject['_type']) => boolean;
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *  type: 'annotation.add',
   *  annotation: {
   *    name: '...',
   *    value: {...},
   *  }
   * })
   * ```
   */
  static addAnnotation: <TSchemaType extends {
    name: string;
  }>(editor: PortableTextEditor, type: TSchemaType, value?: {
    [prop: string]: unknown;
  }) => AddedAnnotationPaths | undefined;
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *  type: 'blur',
   * })
   * ```
   */
  static blur: (editor: PortableTextEditor) => void;
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *  type: 'delete',
   *  at: {...},
   *  direction: '...',
   *  unit: '...',
   * })
   * ```
   */
  static delete: (editor: PortableTextEditor, selection: EditorSelection, options?: EditableAPIDeleteOptions) => void;
  static findDOMNode: (editor: PortableTextEditor, element: PortableTextBlock | PortableTextChild) => Node | undefined;
  static findByPath: (editor: PortableTextEditor, path: Path) => [PortableTextObject | import("@portabletext/schema").PortableTextSpan | import("@portabletext/schema").PortableTextTextBlock<PortableTextObject | import("@portabletext/schema").PortableTextSpan> | undefined, Path | undefined];
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *  type: 'focus',
   * })
   * ```
   */
  static focus: (editor: PortableTextEditor) => void;
  /**
   * @deprecated
   * Use built-in selectors or write your own: https://www.portabletext.org/reference/selectors/
   *
   * ```
   * import * as selectors from '@portabletext/editor/selectors'
   * const editor = useEditor()
   * const focusBlock = useEditorSelector(editor, selectors.getFocusBlock)
   * ```
   */
  static focusBlock: (editor: PortableTextEditor) => PortableTextBlock | undefined;
  /**
   * @deprecated
   * Use built-in selectors or write your own: https://www.portabletext.org/reference/selectors/
   *
   * ```
   * import * as selectors from '@portabletext/editor/selectors'
   * const editor = useEditor()
   * const focusChild = useEditorSelector(editor, selectors.getFocusChild)
   * ```
   */
  static focusChild: (editor: PortableTextEditor) => PortableTextChild | undefined;
  /**
   * @deprecated
   * Use built-in selectors or write your own: https://www.portabletext.org/reference/selectors/
   *
   * ```
   * import * as selectors from '@portabletext/editor/selectors'
   * const editor = useEditor()
   * const selection = useEditorSelector(editor, selectors.getSelection)
   * ```
   */
  static getSelection: (editor: PortableTextEditor) => EditorSelection;
  /**
   * @deprecated
   * Use built-in selectors or write your own: https://www.portabletext.org/reference/selectors/
   *
   * ```
   * import * as selectors from '@portabletext/editor/selectors'
   * const editor = useEditor()
   * const value = useEditorSelector(editor, selectors.getValue)
   * ```
   */
  static getValue: (editor: PortableTextEditor) => PortableTextBlock[] | undefined;
  /**
   * @deprecated
   * Use built-in selectors or write your own: https://www.portabletext.org/reference/selectors/
   *
   * ```
   * import * as selectors from '@portabletext/editor/selectors'
   * const editor = useEditor()
   * const isActive = useEditorSelector(editor, selectors.isActiveStyle(...))
   * ```
   */
  static hasBlockStyle: (editor: PortableTextEditor, blockStyle: string) => boolean;
  /**
   * @deprecated
   * Use built-in selectors or write your own: https://www.portabletext.org/reference/selectors/
   *
   * ```
   * import * as selectors from '@portabletext/editor/selectors'
   * const editor = useEditor()
   * const isActive = useEditorSelector(editor, selectors.isActiveListItem(...))
   * ```
   */
  static hasListStyle: (editor: PortableTextEditor, listStyle: string) => boolean;
  /**
   * @deprecated
   * Use built-in selectors or write your own: https://www.portabletext.org/reference/selectors/
   *
   * ```
   * import * as selectors from '@portabletext/editor/selectors'
   * const editor = useEditor()
   * const isSelectionCollapsed = useEditorSelector(editor, selectors.isSelectionCollapsed)
   * ```
   */
  static isCollapsedSelection: (editor: PortableTextEditor) => boolean;
  /**
   * @deprecated
   * Use built-in selectors or write your own: https://www.portabletext.org/reference/selectors/
   *
   * ```
   * import * as selectors from '@portabletext/editor/selectors'
   * const editor = useEditor()
   * const isSelectionExpanded = useEditorSelector(editor, selectors.isSelectionExpanded)
   * ```
   */
  static isExpandedSelection: (editor: PortableTextEditor) => boolean;
  /**
   * @deprecated
   * Use built-in selectors or write your own: https://www.portabletext.org/reference/selectors/
   *
   * ```
   * import * as selectors from '@portabletext/editor/selectors'
   * const editor = useEditor()
   * const isActive = useEditorSelector(editor, selectors.isActiveDecorator(...))
   * ```
   */
  static isMarkActive: (editor: PortableTextEditor, mark: string) => boolean;
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *  type: 'insert.span',
   *  text: '...',
   *  annotations: [{name: '...', value: {...}}],
   *  decorators: ['...'],
   * })
   * editor.send({
   *  type: 'insert.inline object',
   *  inlineObject: {
   *    name: '...',
   *    value: {...},
   *  },
   * })
   * ```
   */
  static insertChild: <TSchemaType extends {
    name: string;
  }>(editor: PortableTextEditor, type: TSchemaType, value?: {
    [prop: string]: unknown;
  }) => Path | undefined;
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *  type: 'insert.block object',
   *  blockObject: {
   *    name: '...',
   *    value: {...},
   *  },
   *  placement: 'auto' | 'after' | 'before',
   * })
   * ```
   */
  static insertBlock: <TSchemaType extends {
    name: string;
  }>(editor: PortableTextEditor, type: TSchemaType, value?: {
    [prop: string]: unknown;
  }) => Path | undefined;
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *  type: 'insert.break',
   * })
   * ```
   */
  static insertBreak: (editor: PortableTextEditor) => void;
  static isVoid: (editor: PortableTextEditor, element: PortableTextBlock | PortableTextChild) => boolean;
  static isObjectPath: (_editor: PortableTextEditor, path: Path) => boolean;
  static marks: (editor: PortableTextEditor) => string[];
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *  type: 'select',
   *  at: selection,
   * })
   * ```
   */
  static select: (editor: PortableTextEditor, selection: EditorSelection | null) => void;
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *  type: 'annotation.remove',
   *  annotation: {
   *    name: '...',
   *  },
   * })
   * ```
   */
  static removeAnnotation: <TSchemaType extends {
    name: string;
  }>(editor: PortableTextEditor, type: TSchemaType) => void;
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *  type: 'style.toggle',
   *  style: '...',
   * })
   * ```
   */
  static toggleBlockStyle: (editor: PortableTextEditor, blockStyle: string) => void;
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *  type: 'list item.toggle',
   *  listItem: '...',
   * })
   * ```
   */
  static toggleList: (editor: PortableTextEditor, listStyle: string) => void;
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *  type: 'decorator.toggle',
   *  decorator: '...',
   * })
   * ```
   */
  static toggleMark: (editor: PortableTextEditor, mark: string) => void;
  /**
   * @deprecated
   * Use built-in selectors or write your own: https://www.portabletext.org/reference/selectors/
   *
   * ```
   * import * as selectors from '@portabletext/editor/selectors'
   * const editor = useEditor()
   * const selectedValue = useEditorSelector(editor, selectors.getSelectedValue)
   * ```
   */
  static getFragment: (editor: PortableTextEditor) => PortableTextBlock[] | undefined;
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *   type: 'history.undo',
   * })
   * ```
   */
  static undo: (editor: PortableTextEditor) => void;
  /**
   * @deprecated
   * Use `editor.send(...)` instead
   *
   * ```
   * const editor = useEditor()
   * editor.send({
   *   type: 'history.redo',
   * })
   * ```
   */
  static redo: (editor: PortableTextEditor) => void;
  /**
   * @deprecated
   * Use built-in selectors or write your own: https://www.portabletext.org/reference/selectors/
   *
   * ```
   * import * as selectors from '@portabletext/editor/selectors'
   * const editor = useEditor()
   * const isOverlapping = useEditorSelector(editor, selectors.isOverlappingSelection(selectionB))
   * ```
   */
  static isSelectionsOverlapping: (editor: PortableTextEditor, selectionA: EditorSelection, selectionB: EditorSelection) => boolean;
}
/**
 * @beta
 */
type HotkeyOptions = {
  marks?: Record<string, string>;
  custom?: Record<string, (event: BaseSyntheticEvent, editor: PortableTextEditor) => void>;
};
/**
 * @public
 */
type PortableTextEditableProps = Omit<TextareaHTMLAttributes<HTMLDivElement>, 'onPaste' | 'onCopy' | 'onBeforeInput'> & {
  ref?: React.Ref<HTMLDivElement>;
  hotkeys?: HotkeyOptions;
  onBeforeInput?: (event: InputEvent) => void;
  onPaste?: OnPasteFn;
  onCopy?: OnCopyFn;
  rangeDecorations?: RangeDecoration[];
  renderPlaceholder?: RenderPlaceholderFunction;
  scrollSelectionIntoView?: ScrollSelectionIntoViewFunction;
  selection?: EditorSelection;
  spellCheck?: boolean;
};
/**
 * @public
 *
 *
 * The core component that renders the editor. Must be placed within the {@link EditorProvider} component.
 *
 * @example
 * ```tsx
 * import { PortableTextEditable, EditorProvider, defineSchema } from '@portabletext/editor'
 *
 * const schemaDefinition = defineSchema({})
 *
 * function MyComponent() {
 *  return (
 *   <EditorProvider initialConfig={{schemaDefinition}}>
 *    <PortableTextEditable />
 *  </EditorProvider>
 *  )
 * }
 * ```
 * @group Components
 */
declare const PortableTextEditable: import("react").ForwardRefExoticComponent<Omit<PortableTextEditableProps, "ref"> & import("react").RefAttributes<Omit<HTMLDivElement, "as" | "onBeforeInput" | "onPaste">>>;
/**
 * @beta
 * @deprecated `EditableAPIDeleteOptions` is deprecated together with the
 * `PortableTextEditor.delete` static. Send a `delete` behavior event (with
 * an optional `unit`) or a `delete.block` event via `editor.send` instead.
 */
interface EditableAPIDeleteOptions {
  mode?: 'blocks' | 'children' | 'selected';
}
/**
 * @public
 */
type AddedAnnotationPaths = {
  /**
   * @deprecated An annotation may be applied to multiple blocks, resulting
   * in multiple `markDef`'s being created. Use `markDefPaths` instead.
   */
  markDefPath: Path;
  markDefPaths: Array<Path>;
  /**
   * @deprecated Does not return anything meaningful since an annotation
   * can span multiple blocks and spans. If references the span closest
   * to the focus point of the selection.
   */
  spanPath: Path;
};
/** @internal */
interface EditableAPI {
  activeAnnotations: () => PortableTextObject[];
  isAnnotationActive: (annotationType: PortableTextObject['_type']) => boolean;
  addAnnotation: <TSchemaType extends {
    name: string;
  }>(type: TSchemaType, value?: {
    [prop: string]: unknown;
  }) => AddedAnnotationPaths | undefined;
  blur: () => void;
  delete: (selection: EditorSelection, options?: EditableAPIDeleteOptions) => void;
  findByPath: (path: Path) => [PortableTextBlock | PortableTextChild | undefined, Path | undefined];
  findDOMNode: (element: PortableTextBlock | PortableTextChild) => Node | undefined;
  focus: () => void;
  focusBlock: () => PortableTextBlock | undefined;
  focusChild: () => PortableTextChild | undefined;
  getSelection: () => EditorSelection;
  getFragment: () => PortableTextBlock[] | undefined;
  getValue: () => PortableTextBlock[] | undefined;
  hasBlockStyle: (style: string) => boolean;
  hasListStyle: (listStyle: string) => boolean;
  insertBlock: <TSchemaType extends {
    name: string;
  }>(type: TSchemaType, value?: {
    [prop: string]: unknown;
  }) => Path;
  insertChild: <TSchemaType extends {
    name: string;
  }>(type: TSchemaType, value?: {
    [prop: string]: unknown;
  }) => Path;
  insertBreak: () => void;
  isCollapsedSelection: () => boolean;
  isExpandedSelection: () => boolean;
  isMarkActive: (mark: string) => boolean;
  isVoid: (element: PortableTextBlock | PortableTextChild) => boolean;
  isSelectionsOverlapping: (selectionA: EditorSelection, selectionB: EditorSelection) => boolean;
  marks: () => string[];
  redo: () => void;
  removeAnnotation: <TSchemaType extends {
    name: string;
  }>(type: TSchemaType) => void;
  select: (selection: EditorSelection) => void;
  toggleBlockStyle: (blockStyle: string) => void;
  toggleList: (listStyle: string) => void;
  toggleMark: (mark: string) => void;
  undo: () => void;
}
/** @public */
type EditorSelectionPoint = {
  path: Path;
  offset: number;
};
/** @public */
type EditorSelection = {
  anchor: EditorSelectionPoint;
  focus: EditorSelectionPoint;
  backward?: boolean;
} | null;
/**
 * The editor has invalid data in the value that can be resolved by the user
 * @public */
type InvalidValueResolution = {
  autoResolve?: boolean;
  patches: Patch[];
  description: string;
  action: string;
  item: PortableTextBlock[] | PortableTextBlock | PortableTextChild | undefined;
  /**
   * i18n keys for the description and action
   *
   * These are in addition to the description and action properties, to decouple the editor from
   * the i18n system, and allow usage without it. The i18n keys take precedence over the
   * description and action properties, if i18n framework is available.
   */
  i18n: {
    description: `inputs.portable-text.invalid-value.${Lowercase<string>}.description`;
    action: `inputs.portable-text.invalid-value.${Lowercase<string>}.action`;
    values?: Record<string, string | number | string[]>;
  };
};
/** @beta */
type OnPasteResult = {
  /**
   * Delivered as-is to the `insert.blocks` Behavior event and validated
   * against the schema when inserted.
   */
  insert?: TypedObject[];
  path?: Path;
} | undefined;
/**
 * @beta
 */
type OnPasteResultOrPromise = OnPasteResult | Promise<OnPasteResult>;
/** @beta */
interface PasteData {
  event: ClipboardEvent$1;
  path: Path;
  schemaTypes: EditorSchema;
  value: PortableTextBlock[] | undefined;
}
/**
 * @beta
 * It is encouraged not to return `Promise<undefined>` from the `OnPasteFn` as
 * a mechanism to fall back to the native paste behaviour. This doesn't work in
 * all cases. Always return plain `undefined` if possible.
 **/
type OnPasteFn = (data: PasteData) => OnPasteResultOrPromise;
/** @beta */
type OnCopyFn = (event: ClipboardEvent$1<HTMLDivElement | HTMLSpanElement>) => undefined | unknown;
/** @public */
type RenderEditableFunction = (props: PortableTextEditableProps) => JSX.Element;
/** @public */
type RenderPlaceholderFunction = () => React.ReactNode;
/** @public */
type ScrollSelectionIntoViewFunction = (editor: PortableTextEditor, domRange: globalThis.Range) => void;
/**
 * Details passed to a `RangeDecoration`'s `onMoved` callback.
 * @public */
interface RangeDecorationOnMovedDetails {
  rangeDecoration: RangeDecoration;
  newSelection: EditorSelection;
  origin: 'remote' | 'local';
}
/**
 * Props passed to a `Decoration`'s `render`.
 * @beta
 */
interface DecorationRenderProps {
  children: ReactNode;
  /**
   * `true` for the fragment that contains the decoration's start point.
   * A collapsed decoration's single fragment is both `isFirst` and
   * `isLast`. Unique per decoration, so one-time chrome renders once.
   */
  isFirst: boolean;
  /**
   * `true` for the fragment that contains the decoration's end point. A
   * collapsed decoration's single fragment is both `isFirst` and
   * `isLast`. Unique per decoration, so one-time chrome renders once.
   */
  isLast: boolean;
}
/**
 * A UI affordance that wraps a selection range in the editor with a custom
 * component, for example to highlight search results, mark validation
 * errors on specific words, or draw user presence.
 * @public */
interface RangeDecoration {
  /**
   * The component that renders the range decoration. It receives the
   * decorated text as its children.
   *
   * The component can render more than once for one decoration: the range
   * is split into segments at formatting boundaries and where it overlaps
   * other decorations, and each segment gets its own wrapper. Where
   * decorations overlap, their components nest, first in array order
   * outermost.
   *
   * @example
   * ```tsx
   * (rangeComponentProps: PropsWithChildren) => (
   *    <SearchResultHighlight>
   *      {rangeComponentProps.children}
   *    </SearchResultHighlight>
   *  )
   * ```
   */
  component: (props: PropsWithChildren) => ReactElement<any>;
  /**
   * The editor content selection range to decorate.
   */
  selection: EditorSelection;
  /**
   * Called when edits move the decorated range. The details carry the new
   * selection (`null` when the range is lost) and whether the edit was
   * `local` or `remote`.
   */
  onMoved?: (details: RangeDecorationOnMovedDetails) => void;
  /**
   * A custom payload that can be set on the range decoration.
   */
  payload?: Record<string, unknown>;
}
/**
 * A decoration registered through `editor.registerDecorations`,
 * independent of any `PortableTextEditable`'s `rangeDecorations` prop.
 * Unrelated to schema decorators (marks like `strong`): this `Decoration`
 * is the registered counterpart of the `rangeDecorations` prop's
 * `RangeDecoration`.
 * @beta
 */
interface Decoration {
  /**
   * Identity for reconciliation: an `update` call matches decorations to
   * their previous state by `id`, not by array position. Unique within
   * one registration (duplicates throw). The same `id` used across
   * different registrations refers to different decorations. Unrelated
   * to Portable Text's `_key`.
   */
  id: string;
  /**
   * Discriminates the decoration's anchor shape. Only `'range'` exists
   * today.
   */
  type: 'range';
  /**
   * The editor content range to decorate. Feed a captured editor
   * selection straight in, for example a peer's presence selection or
   * the range a search match was found at. An edit that destroys the
   * underlying content kills the decoration (a mapping with
   * `newRange: null`). "No position" is omission from the array, not a
   * nullable `range`.
   */
  range: NonNullable<EditorSelection>;
  /**
   * Plain-called factory returning an element tree. No hooks in the
   * body: state lives in components the tree mounts. Ignoring
   * `children` is legal (widget decorations).
   *
   * Chrome that carries no document text must be CSS generated content
   * or a `contentEditable={false}` element: bare text or editable
   * elements injected into the tree desync the caret from the document
   * (arrow keys jump or stick around the decorated range).
   *
   * The tree can render more than once for one decoration: the range is
   * split into segments at formatting boundaries and where it overlaps
   * other decorations, and each segment gets its own wrapper. Where
   * decorations overlap, they nest, first in array order outermost.
   */
  render: (props: DecorationRenderProps) => ReactElement;
}
/**
 * What one engine operation did to one registered decoration's range.
 * @beta
 */
type DecorationMapping = {
  /** The decoration's `id`, matching the `Decoration` it describes. */
  id: string;
  /** The range the decoration held before the operation. */
  previousRange: NonNullable<EditorSelection>;
  /**
   * The range after the operation. `null` means the operation destroyed
   * the decoration. Undo does not revive it: an `update()` with a
   * different range (or a drop and re-add) is required.
   */
  newRange: NonNullable<EditorSelection> | null;
  /** Whether the operation changed content inside `previousRange`. */
  contentTouched: boolean;
  /** Whether the operation came from a local edit or a remote one. */
  origin: 'local' | 'remote';
};
/**
 * One registered decoration's live position, as returned by
 * `DecorationRegistration.getDecorations`.
 * @beta
 */
type DecorationPosition = {
  id: string;
  range: NonNullable<EditorSelection>;
};
/**
 * The handle returned by `editor.registerDecorations`.
 * @beta
 */
interface DecorationRegistration {
  /** Full-set replacement, reconciled by `id`. */
  update(decorations: Array<Decoration>): void;
  /** A no-op if already unregistered. */
  unregister(): void;
  /**
   * Live decorations at call time: id + edit-adjusted range. Destroyed and
   * removed decorations are absent. Fresh array per call, with no
   * reference stability or change cadence. Reflects a completed `update()`
   * immediately and a burst of `onMapped` calls as of the latest one.
   * Empty before the editor's `ready` event.
   */
  getDecorations(): Array<DecorationPosition>;
}
type TextDirection = 'forward' | 'backward';
/**
 * `Point` objects refer to a specific location in a text node in the editor
 * document. Its path refers to the location of the node in the tree, and its
 * offset refers to the distance into the node's string of text. Points can
 * only refer to `Text` nodes.
 */
interface Point {
  path: Path;
  offset: number;
}
/**
 * `Range` objects are a set of points that refer to a specific span of the editor
 * document. They can define a span inside a single node or a can span across
 * multiple nodes.
 */
interface Range {
  anchor: Point;
  focus: Point;
}
/**
 * Insert a node before or after the sibling at `path`.
 *
 * @beta
 */
type InsertOperation = {
  type: 'insert';
  path: Path;
  node: Node$1;
  position: 'before' | 'after';
  inverse?: UnsetOperationData;
};
/**
 * Insert `text` into the span at `path`, at `offset`.
 *
 * @beta
 */
type InsertTextOperation = {
  type: 'insert.text';
  path: Path;
  offset: number;
  text: string;
};
/**
 * Remove `text` from the span at `path`, starting at `offset`.
 *
 * @beta
 */
type RemoveTextOperation = {
  type: 'remove.text';
  path: Path;
  offset: number;
  text: string;
};
/**
 * Data for a `set` inverse (no nested inverse field).
 *
 * @beta
 */
type SetOperationData = {
  type: 'set';
  path: Path;
  value: unknown;
};
/**
 * Data for an `insert` inverse (no nested inverse field).
 *
 * @beta
 */
type InsertOperationData = {
  type: 'insert';
  path: Path;
  node: Node$1;
  position: 'before' | 'after';
};
/**
 * Data for an `unset` inverse (no nested inverse field).
 *
 * @beta
 */
type UnsetOperationData = {
  type: 'unset';
  path: Path;
};
/**
 * Set a property on a node. The path is `[...nodePath, propertyName]`.
 *
 * When `inverse` is provided, the operation can be undone. Remote operations
 * (applied via `withRemoteChanges`) skip the history plugin and do not need
 * inverse data.
 *
 * @beta
 */
type SetOperation = {
  type: 'set';
  path: Path;
  value: unknown;
  inverse?: SetOperationData | UnsetOperationData;
};
/**
 * Remove a property from a node, or remove a node from its parent.
 *
 * Property removal: path is `[...nodePath, propertyName]` (last segment is a string).
 * Node removal: path is `[...parentPath, arrayFieldName, {_key: nodeKey}]`
 * (last segment is a keyed segment pointing to the node to remove).
 *
 * The `inverse` of a node removal carries the removed node; the operation
 * itself only carries its path.
 *
 * @beta
 */
type UnsetOperation = {
  type: 'unset';
  path: Path;
  inverse?: SetOperationData | InsertOperationData;
};
type SetSelectionOperation = {
  type: 'set.selection';
  properties: null;
  newProperties: Range;
} | {
  type: 'set.selection';
  properties: Partial<Range>;
  newProperties: Partial<Range>;
} | {
  type: 'set.selection';
  properties: Range;
  newProperties: null;
};
/**
 * A low-level operation applied by the editor engine. Every change to the
 * editor (local edits, remote patches, value sync, normalization fixes,
 * undo/redo) is expressed as a sequence of these operations.
 *
 * The vocabulary is closed: the dot-named operations (`insert.text`,
 * `remove.text`) are not namespaces that grow members.
 *
 * `inverse` is present when the engine needs the operation to be
 * reversible (local structural operations) and carries what is needed to
 * reverse it. Operations applied from remote patches do not carry it.
 *
 * @beta
 */
type EngineOperation = InsertOperation | SetOperation | UnsetOperation | SetSelectionOperation | InsertTextOperation | RemoveTextOperation;
type DecoratedRange = Range & {
  rangeDecoration: RangeDecoration | Decoration;
  kind: RangeDecorationSourceKind;
  merge: (leaf: PortableTextSpan, decoration: object) => void;
};
type RangeDecorationSourceKind = 'prop' | 'registered';
/**
 * `RangeRef` objects keep a specific range in a document synced over time as new
 * operations are applied to the editor. You can access their `current` property
 * at any time for the up-to-date range value.
 */
interface RangeRef {
  current: Range | null;
  affinity: 'forward' | 'backward' | 'outward' | 'inward' | null;
  unref(): Range | null;
}
type StringDiff = {
  start: number;
  end: number;
  text: string;
};
type TextDiff = {
  id: number;
  path: Path;
  diff: StringDiff;
};
/**
 * Types.
 */
type DOMNode = globalThis.Node;
type DOMRange = globalThis.Range;
type DOMSelection = globalThis.Selection;
type DOMStaticRange = globalThis.StaticRange;
declare global {
  interface Window {
    Selection: (typeof Selection)['constructor'];
    DataTransfer: (typeof DataTransfer)['constructor'];
    Node: (typeof Node)['constructor'];
  }
}
type DOMPoint = [Node, number];
type Action = {
  at?: Point | Range;
  run: () => void;
};
/**
 * A DOM-specific version of the `Editor` interface.
 */
interface DOMEditor extends BaseEditor {
  hasEditableTarget: (editor: Editor$1, target: EventTarget | null) => target is DOMNode;
  hasRange: (editor: Editor$1, range: Range) => boolean;
  hasSelectableTarget: (editor: Editor$1, target: EventTarget | null) => boolean;
  hasTarget: (editor: Editor$1, target: EventTarget | null) => target is DOMNode;
  isTargetInsideNonReadonlyVoid: (editor: Editor$1, target: EventTarget | null) => boolean;
  isNodeMapDirty: boolean;
  domWindow: Window | null;
  domElement: HTMLElement | null;
  readOnly: boolean;
  focused: boolean;
  composing: boolean;
  userSelection: RangeRef | null;
  onContextChange: ((options?: {
    operation?: EngineOperation;
  }) => void) | null;
  scheduleFlush: (() => void) | null;
  pendingDiffs: TextDiff[];
  pendingAction: Action | null;
  pendingSelection: Range | null;
  forceRender: (() => void) | null;
}
interface DOMEditorInterface {
  /**
   * Blur the editor.
   */
  blur: (editor: Editor$1) => void;
  /**
   * Find the DOM node that implements DocumentOrShadowRoot for the editor.
   */
  findDocumentOrShadowRoot: (editor: Editor$1) => Document | ShadowRoot;
  /**
   * Focus the editor.
   */
  focus: (editor: Editor$1, options?: {
    retries: number;
  }) => void;
  /**
   * Return the host window of the current editor.
   */
  getWindow: (editor: Editor$1) => Window;
  /**
   * Check if a DOM node is within the editor.
   */
  hasDOMNode: (editor: Editor$1, target: DOMNode, options?: {
    editable?: boolean;
  }) => boolean;
  /**
   * Check if the target is editable and in the editor.
   */
  hasEditableTarget: (editor: Editor$1, target: EventTarget | null) => target is DOMNode;
  /**
   *
   */
  hasRange: (editor: Editor$1, range: Range) => boolean;
  /**
   * Check if the target can be selectable
   */
  hasSelectableTarget: (editor: Editor$1, target: EventTarget | null) => boolean;
  /**
   * Check if the target is in the editor.
   */
  hasTarget: (editor: Editor$1, target: EventTarget | null) => target is DOMNode;
  /**
   * Check if the target is inside void and in an non-readonly editor.
   */
  isTargetInsideNonReadonlyVoid: (editor: Editor$1, target: EventTarget | null) => boolean;
  /**
   * Find a native DOM selection point from a point.
   */
  toDOMPoint: (editor: Editor$1, point: Point) => DOMPoint;
  /**
   * Find a native DOM range from a `range`.
   *
   * Notice: the returned range will always be ordinal regardless of the direction of the input `range` due to DOM API limit.
   *
   * there is no way to create a reverse DOM Range using Range.setStart/setEnd
   * according to https://dom.spec.whatwg.org/#concept-range-bp-set.
   */
  toDOMRange: (editor: Editor$1, range: Range) => DOMRange;
  /**
   * Find a point from a DOM selection's `domNode` and `domOffset`.
   */
  toSelectionPoint: <T extends boolean>(editor: Editor$1, domPoint: DOMPoint, options: {
    exactMatch: boolean;
    suppressThrow: T;
    /**
     * The direction to search for leaf nodes if `domPoint` is
     * non-editable and non-void.
     */
    searchDirection?: 'forward' | 'backward';
  }) => T extends true ? Point | null : Point;
  /**
   * Find a range from a DOM range or selection.
   */
  toEditorSelection: <T extends boolean>(editor: Editor$1, domRange: DOMRange | DOMStaticRange | DOMSelection, options: {
    exactMatch: boolean;
    suppressThrow: T;
  }) => T extends true ? Range | null : Range;
}
declare const DOMEditor: DOMEditorInterface;
/**
 * The `Location` interface is a union of the ways to refer to a specific
 * location in a document: paths, points or ranges.
 *
 * Methods will often accept a `Location` instead of requiring only a `Path`,
 * `Point` or `Range`. This eliminates the need for developers to manage
 * converting between the different interfaces in their own code base.
 */
type Location = Path | Point | Range;
/**
 * `PathRef` objects keep a specific path in a document synced over time as new
 * operations are applied to the editor. You can access their `current` property
 * at any time for the up-to-date path value.
 */
interface PathRef {
  current: Path | null;
  affinity: 'forward' | 'backward' | null;
  unref(): Path | null;
}
interface PathRefInterface {
  transform: (ref: PathRef, op: EngineOperation) => void;
}
declare const PathRef: PathRefInterface;
/**
 * `PointRef` objects keep a specific point in a document synced over time as new
 * operations are applied to the editor. You can access their `current` property
 * at any time for the up-to-date point value.
 */
interface PointRef {
  current: Point | null;
  affinity: TextDirection | null;
  unref(): Point | null;
}
interface PointRefInterface {
  transform: (ref: PointRef, op: EngineOperation) => void;
}
declare const PointRef: PointRefInterface;
/**
 * The `Editor` interface stores all the state of a editor. It is extended
 * by plugins that wish to add their own helpers and implement new behaviors.
 */
interface BaseEditor {
  operations: EngineOperation[];
  operationListeners: {
    before: Array<OperationListener>;
    after: Array<OperationListener>;
  };
  dirtyPaths: Path[];
  dirtyPathKeys: Set<string>;
  flushing: boolean;
  normalizing: boolean;
  pathRefs: Set<PathRef>;
  pointRefs: Set<PointRef>;
  rangeRefs: Set<RangeRef>;
  apply: (operation: EngineOperation) => void;
  normalizeNode: (entry: [Editor$1 | Node$1, Path], options?: {
    operation?: EngineOperation;
  }) => void;
  onChange: (options?: {
    operation?: EngineOperation;
  }) => void;
  shouldNormalize: ({ iteration, dirtyPaths, operation }: {
    iteration: number;
    initialDirtyPathsLength: number;
    dirtyPaths: Path[];
    operation?: EngineOperation;
  }) => boolean;
  select: (target: Location) => void;
  setSelection: (props: Partial<Range>) => void;
}
type Editor$1 = BaseEditor & DOMEditor & PortableTextEditorEngine;
/**
 * The operation channel is the single place to observe every `EngineOperation` the
 * engine applies.
 *
 * Guarantees:
 *
 * - Listeners run synchronously, in subscription order.
 * - `before` listeners run before the operation touches the editor state,
 *   `after` listeners run once the operation (including any normalization it
 *   triggered) has been fully applied.
 * - Normalization fixes re-enter `editor.apply`, so a fix operation's events
 *   fire nested between the triggering operation's `before` and `after`
 *   events — a fix's `after` listeners run before the triggering
 *   operation's.
 */
type OperationOrigin = 'local' | 'remote' | 'undo' | 'redo' | 'normalization';
type OperationEvent = {
  /**
   * The operation object is enriched in place during apply — `inverse` gets
   * populated and inserted nodes may be re-keyed — so `after` listeners
   * observe the final operation.
   */
  operation: EngineOperation;
  /**
   * `editor.snapshot.context.value` captured at apply entry. Operations
   * replace the value array instead of mutating it, so this reference keeps
   * pointing at the pre-apply value.
   */
  beforeValue: Array<PortableTextBlock>;
  /**
   * `editor.snapshot.context.selection` captured at apply entry. Selections
   * are replaced, not mutated, so this reference stays pre-apply.
   */
  beforeSelection: EditorSelection;
  /**
   * Whether `editor.operations` already held unflushed operations at apply
   * entry.
   */
  operationsInProgress: boolean;
  isPatching: boolean;
  withHistory: boolean;
  undoStepId: string | undefined;
  /**
   * Derived from `applyContext`, for declarative filtering.
   */
  origin: OperationOrigin;
  /**
   * A frozen snapshot of `editor.applyContext` at apply entry: the frame
   * stack `origin` was derived from.
   */
  context: ReadonlyArray<ApplyContextFrame>;
};
type OperationListener = (event: OperationEvent) => void;
/**
 * A frame pushed onto `editor.applyContext` for the duration of an
 * attribution bracket (remote changes, undo, redo, normalization). Brackets
 * nest, so a normalization that fires while replaying a remote patch pushes
 * a `normalization` frame on top of the still-active `remote` one; both
 * stay visible to `getOrigin` below instead of only the innermost.
 */
type ApplyContextFrame = {
  kind: 'remote';
  source: 'patches' | 'update-value' | 'initial-sync';
} | {
  kind: 'undo';
} | {
  kind: 'redo';
} | {
  kind: 'normalization';
};
type HistoryItem = {
  operations: EngineOperation[];
  timestamp: Date;
};
interface History {
  redos: HistoryItem[];
  undos: HistoryItem[];
}
type RemotePatch = {
  patch: Patch;
  time: Date;
  snapshot: PortableTextBlock[] | undefined;
  previousSnapshot: PortableTextBlock[] | undefined;
};
interface PortableTextEditorEngine extends DOMEditor {
  _key: 'editor';
  _type: 'editor';
  /**
   * The attribution bracket stack: pushed on entry and popped in `finally`
   * by `withRemoteChanges`, `pluginUndoing`, `pluginRedoing`, and the
   * normalization brackets. `getOrigin` (`engine/core/apply-context.ts`)
   * reduces it to an `OperationOrigin`.
   */
  applyContext: Array<ApplyContextFrame>;
  containers: ResolvedContainers;
  annotations: Map<string, AnnotationConfig>;
  blockObjects: Map<string, BlockObjectConfig>;
  decorators: Map<string, DecoratorConfig>;
  inlineObjects: Map<string, InlineObjectConfig>;
  spans: Map<string, SpanConfig>;
  textBlocks: Map<string, TextBlockConfig>;
  decoratedRanges: Array<DecoratedRange>;
  blockIndexMap: Map<string, number>;
  history: History;
  /**
   * Per-notify pending flags for the segmented selector channels
   * (`EngineSelectorChannel`). Set where the corresponding state mutates
   * (registration map swaps in `register-node-on-engine.ts`) and consumed
   * by the React layer's `onContextChange` dispatch; cleared only when
   * the notification is delivered.
   */
  selectorChannelsPending: {
    registrations: boolean;
  };
  /**
   * Serialized paths of sibling groups (a node's keyed child array, or the
   * root value array as `''`) whose children have been verified to carry no
   * duplicate `_key`s. Per-node duplicate-key normalization skips groups
   * listed here. The op stream removes a group only when an operation
   * changes that group's own direct membership (insert/remove/re-key/replace
   * of a direct child), so an edit deep inside one group never forces a
   * re-scan of its ancestors, and an operation that introduces a subtree
   * also removes that subtree's groups so a reused key can't inherit a stale
   * verdict. Works identically at every depth; the root is just the group
   * with the empty path.
   */
  verifiedUniqueChildGroups: Set<string>;
  remotePatches: Array<RemotePatch>;
  undoStepId: string | undefined;
  isDeferringMutations: boolean;
  /**
   * The last host value recorded by a value sync that changed the engine. A
   * pristine block equal to it is persisted content, not the local
   * placeholder. Syncs that write nothing are not recorded: hosts mirror
   * `mutation.value` back as `update value`, and such an echo of the
   * editor's own state (its placeholder included) is not a claim that the
   * value is persisted. Patch generation also records the value when this
   * editor's own `insert` puts a pristine block into an empty field, since
   * the host then holds that block.
   */
  lastSyncedValue: Array<PortableTextBlock> | undefined;
  /**
   * True while this editor's own emitted patch stream has destroyed the
   * field (a root `unset([])` went out) and not yet re-materialized it (a
   * root `setIfMissing` or `set` went out since). While true, patch
   * generation rebuilds the field before targeting it again, and both it
   * and remote root inserts treat a placeholder equal to `lastSyncedValue`
   * as unpersisted rather than as proof the field survived.
   */
  valueUnsetEmitted: boolean;
  isPatching: boolean;
  isPerformingBehaviorOperation: boolean;
  withHistory: boolean;
  /**
   * The current {@link EditorSnapshot}. Reassigned (new object reference)
   * whenever the editor's observable state changes, and only then. Reads
   * are reference-stable between mutations, which lets
   * `useSyncExternalStore` short-circuit before invoking selectors.
   *
   * `editor.getSnapshot()` returns this property. Internal callers can
   * also read it directly to avoid building snapshots ad-hoc.
   */
  snapshot: EditorSnapshot;
}
/**
 * @public
 */
type EditorContext = {
  converters: Array<Converter>;
  keyGenerator: () => string;
  readOnly: boolean;
  schema: EditorSchema;
  selection: EditorSelection;
  value: Array<PortableTextBlock>;
  /**
   * Map of registered editable containers keyed by their bare
   * block-object `_type` (e.g. `'callout'`, `'table'`).
   *
   * Each entry is a {@link RegisteredContainer} carrying `type`,
   * the array `field` that holds the container's editable children,
   * and (when present) the nested positional `of` registrations the
   * engine consults when it descends into the container. The render
   * callback is engine-internal and not surfaced here.
   *
   * Only top-level registrations appear as flat entries. A `_type`
   * registered only inside a parent's `of` is reachable through that
   * parent's `of`, not as a top-level entry. For position-aware descent,
   * walk the entries with `getContainerChildren` from
   * `@portabletext/editor/traversal`.
   *
   * @public
   */
  containers: Containers;
};
/**
 * @public
 */
type EditorSnapshot = {
  context: EditorContext;
  blockIndexMap: ReadonlyMap<string, number>;
  /**
   * @beta
   * Subject to change
   */
  decoratorState: Record<string, boolean | undefined>;
};
/**
 * @public
 */
type BehaviorGuard<TBehaviorEvent, TGuardResponse> = (payload: {
  snapshot: EditorSnapshot;
  event: TBehaviorEvent;
  dom: EditorDom;
}) => TGuardResponse | false;
/**
 * @public
 */
type Behavior<TBehaviorEventType extends '*' | `${BehaviorEventTypeNamespace}.*` | BehaviorEvent['type'] = '*' | `${BehaviorEventTypeNamespace}.*` | BehaviorEvent['type'], TGuardResponse = true, TBehaviorEvent extends ResolveBehaviorEvent<TBehaviorEventType> = ResolveBehaviorEvent<TBehaviorEventType>> = {
  /**
   * Editor Event that triggers this Behavior.
   */
  on: TBehaviorEventType;
  /**
   * Predicate function that determines if the Behavior should be executed.
   * Returning a non-nullable value from the guard will pass the value to the
   * actions and execute them.
   */
  guard?: BehaviorGuard<TBehaviorEvent, TGuardResponse>;
  /**
   * Array of Behavior Action sets.
   * Each set represents a step in the history stack.
   */
  actions: Array<BehaviorActionSet<TBehaviorEvent, TGuardResponse>>;
};
/**
 * @public
 *
 * @example
 *
 * ```tsx
 * import {defineBehavior, raise} from '@portabletext/editor/behaviors'
 *
 * const noLowerCaseA = defineBehavior({
 *   on: 'insert.text',
 *   guard: ({event, snapshot}) => event.text === 'a',
 *   actions: [({event, snapshot}) => [raise({type: 'insert.text', text: 'A'})]],
 * })
 * ```
 *
 */
declare function defineBehavior<TPayload extends Record<string, unknown>, TBehaviorEventType extends '*' | `${BehaviorEventTypeNamespace}.*` | BehaviorEvent['type'] = CustomBehaviorEvent['type'], TGuardResponse = true>(behavior: Behavior<TBehaviorEventType, TGuardResponse, ResolveBehaviorEvent<TBehaviorEventType, TPayload>>): Behavior;
/**
 * The document-changing operations emitted through
 * `editor.on('operation', ...)`. Every change to the editor (local edits,
 * remote patches, value sync, normalization fixes, undo/redo) is expressed
 * as a sequence of these five operations.
 *
 * The vocabulary is closed: there are exactly five, listed explicitly so
 * that a new engine operation never becomes public surface by default, and
 * the dot-named ones (`insert.text`, `remove.text`) are not namespaces that
 * grow members.
 *
 * Selection movements are not emitted on this stream; subscribe to the
 * `selection` event instead.
 *
 * Operation objects are the engine's own, passed by reference: treat them
 * as read-only and copy anything you retain beyond the listener call.
 *
 * Delivery order: normalization fix operations are delivered adjacent to
 * the operation that triggered them, but whether a fix arrives before or
 * after its trigger depends on how the trigger was applied (a fix
 * re-enters the engine's apply, so an unbatched trigger delivers the fix
 * first; batched applies deliver fixes after the batch). Do not assume
 * delivery order equals application order under normalization: seed
 * derived state from `editor.getSnapshot()` and recompute on change
 * rather than replaying deltas blindly.
 *
 * `inverse`, when present, reflects what the engine itself needs to make
 * the operation reversible. Its presence follows the engine's history
 * policy and is not a stable per-operation contract.
 *
 * @beta
 */
type Operation = InsertOperation | InsertTextOperation | RemoveTextOperation | SetOperation | UnsetOperation;
/**
 * @public
 */
type EditorEmittedEvent = {
  type: 'blurred';
  event: FocusEvent<HTMLDivElement, Element>;
} | {
  type: 'editable';
} | {
  type: 'focused';
  event: FocusEvent<HTMLDivElement, Element>;
} | {
  type: 'invalid value';
  resolution: InvalidValueResolution | null;
  value: Array<PortableTextBlock> | undefined;
} | MutationEvent | {
  /**
   * @beta
   * Emitted synchronously for every document-changing operation the
   * engine applies (`set.selection` is excluded; the `selection` event
   * serves selection observers), including operations from initial
   * value sync and normalization, unlike `patch` and `mutation`
   * events, which are held back until the editor is dirty. Do not
   * dispatch editor events from a listener; read current state via
   * `editor.getSnapshot()`.
   *
   * The `operation` object is the engine's own, passed by reference:
   * treat it as read-only and copy anything you retain. Normalization
   * fix operations are delivered adjacent to the operation that
   * triggered them, but not in a guaranteed order; see the
   * {@link Operation} docs for the delivery-order contract. Subscribers
   * attached after setup receive only subsequent operations: seed
   * derived state from `editor.getSnapshot()` when subscribing, then
   * apply deltas.
   */
  type: 'operation';
  operation: Operation;
  /**
   * Where the change that produced this operation came from:
   * `'local'` for changes made in this editor (edits, undo/redo),
   * `'remote'` for changes applied from the outside (`patches`,
   * `update value`, and the initial value sync). A normalization fix
   * (a repaired key, a merged span) reports the origin of the change
   * that triggered it.
   */
  origin: 'local' | 'remote';
} | PatchEvent | {
  type: 'read only';
} | {
  type: 'ready';
} | {
  type: 'selection';
  selection: EditorSelection;
} | {
  type: 'value changed';
  value: Array<PortableTextBlock> | undefined;
};
/**
 * @public
 */
type MutationEvent = {
  type: 'mutation';
  patches: Array<Patch>;
  value: Array<PortableTextBlock> | undefined;
};
type PatchEvent = {
  type: 'patch';
  patch: Patch;
};
/**
 * @public
 */
type EditorConfig = {
  keyGenerator?: () => string;
  readOnly?: boolean;
  initialValue?: Array<PortableTextBlock>;
  schemaDefinition: SchemaDefinition;
};
/**
 * @public
 */
type EditorEvent = ExternalEditorEvent | ExternalBehaviorEvent | {
  /**
   * Hands the editor the host's latest snapshot of the value so it can
   * reconcile. A snapshot equal to the previous one the host sent is
   * ignored, even if the editor's content has since diverged from it
   * through local edits. Any other snapshot is reconciled against the
   * editor's current content, block by block: each block that differs
   * from the snapshot is replaced by the snapshot's version.
   *
   * This includes blocks with local edits the snapshot doesn't contain
   * yet, so those edits are lost. Only send snapshots that include
   * everything the editor has emitted. To apply other writers' changes
   * while the user is editing, send them as `patches` instead.
   *
   * Reconciliation is not an edit: it emits no `patch` or `mutation`
   * events and adds no history step. While local changes are in
   * flight, it is deferred until they have flushed. `undefined` and
   * `[]` are the same empty snapshot: sending either when the previous
   * snapshot was also empty is a no-op and never clears locally typed
   * content.
   *
   * To change content programmatically, use editing events so the
   * change flows through behaviors and emits patches; to reset the
   * editor wholesale, remount it with a fresh `initialValue`.
   */
  type: 'update value';
  value: Array<PortableTextBlock> | undefined;
};
/**
 * @public
 */
type Editor = {
  dom: EditorDom;
  getSnapshot: () => EditorSnapshot;
  /**
   * @public
   */
  registerBehavior: (config: {
    behavior: Behavior;
  }) => () => void;
  /**
   * Register a node renderer. The `node` argument is the result of one
   * of the `defineX` factories (`defineContainer`, `defineTextBlock`,
   * `defineSpan`, `defineBlockObject`, `defineInlineObject`,
   * `defineDecorator`, `defineAnnotation`). Returns a function that
   * unregisters the node when called.
   *
   * @public
   */
  registerNode: (config: {
    node: RegistrableNode;
  }) => () => void;
  /**
   * @beta
   *
   * Register decorations, independent of any `PortableTextEditable`'s
   * `rangeDecorations` prop. Multiple sources (the prop and any number
   * of registrations) compose: their decorations flatten with every
   * `PortableTextEditable`'s prop decorations first (in mount order when
   * there's more than one editable), then each registration in the order
   * it was made. The prop always renders outermost, even when a
   * registration's decoration mounts before the `PortableTextEditable`
   * carrying the prop. Nesting is outer-to-inner across sources the same
   * way array order nests within one registration.
   *
   * Each decoration needs a stable, unique `id` so `update` can
   * reconcile by identity: a decoration whose `id` carries over keeps its
   * live position (and any in-flight move) across the call, only
   * adopting a new `range` when the `id`'s `range` actually changed,
   * while always picking up a new `render` reference. Registering (or
   * updating with) more than one decoration sharing an `id` throws
   * synchronously, before any state change. `update` and `unregister`
   * after `unregister` are no-ops.
   *
   * Registered decorations keep transforming and delivering `onMapped`
   * while the editor is read-only; the `rangeDecorations` prop freezes
   * when read-only.
   *
   * This is the low-level primitive higher-level decoration tooling
   * builds on.
   */
  registerDecorations: (config: {
    decorations: Array<Decoration>;
    /**
     * Synchronous, per engine operation that moved, touched, or
     * destroyed at least one of this registration's decorations, one
     * entry per affected decoration. Fires mid-apply: do not dispatch
     * editor events from it. Fixed at registration. No calls before
     * `ready`, none from `update()` reconciliation.
     */
    onMapped?: (mappings: Array<DecorationMapping>) => void;
  }) => DecorationRegistration;
  send: (event: EditorEvent) => void;
  /**
   * Register an event listener.
   *
   * With `{batch: true}` the listener is called once per burst with
   * `Array<Event>`, every matching event emitted before control returns to the
   * event loop (one synchronous `editor.send` worth, normalization included),
   * in delivery order, on the trailing microtask. That is the same boundary at
   * which the editor settles its own state, so each call is one fully-applied,
   * normalized change. Without it (the default), the listener runs
   * synchronously for every event and receives a single event.
   */
  on: {
    <TType extends EditorEmittedEvent['type'] | '*'>(type: TType, listener: (events: Array<EditorEmittedEvent & (TType extends '*' ? unknown : {
      type: TType;
    })>) => void, options: {
      batch: true;
    }): {
      unsubscribe: () => void;
    };
    <TType extends EditorEmittedEvent['type'] | '*'>(type: TType, listener: (event: EditorEmittedEvent & (TType extends '*' ? unknown : {
      type: TType;
    })) => void, options?: {
      batch?: false;
    }): {
      unsubscribe: () => void;
    };
  };
  /**
   * Subscribe to editor state changes. The observer's `next` callback fires
   * with the current `EditorSnapshot` on relevant transitions (selection
   * updates, content mutations, behavior dispatch, configuration changes).
   *
   * Notifications are coalesced: a synchronous burst of transitions (e.g. the
   * many operations one action applies, like undoing a large delete) delivers
   * a single `next` with the settled snapshot on the next microtask, rather
   * than one `next` per transition. The snapshot is cumulative, so only
   * intermediate per-transition states are skipped. To observe every
   * operation, use `editor.on('operation', ...)`.
   *
   * The editor has no terminal state and no error path, so `error` and
   * `complete` are part of the observable contract but never fire. They are
   * kept for structural compatibility with `useSyncExternalStore`,
   * `@xstate/react`'s `useSelector`, and other observer-shaped consumers.
   */
  subscribe(observer: {
    next?: (snapshot: EditorSnapshot) => void;
    error?: (err: unknown) => void;
    complete?: () => void;
  }): {
    unsubscribe: () => void;
  };
};
/**
 * @public
 */
type EditorProviderProps = {
  initialConfig: EditorConfig;
  children?: React$1.ReactNode;
};
/**
 * @public
 * The EditorProvider component is used to set up the editor context and configure the Portable Text Editor.
 * @example
 * ```tsx
 * import {EditorProvider} from '@portabletext/editor'
 *
 * function App() {
 *  return (
 *    <EditorProvider initialConfig={{ ... }} >
 *      ...
 *    </EditorProvider>
 *  )
 * }
 *
 * ```
 * @group Components
 */
declare function EditorProvider(props: EditorProviderProps): React$1.JSX.Element;
/**
 * @public
 */
type EditorSelector<TSelected> = (snapshot: EditorSnapshot) => TSelected;
/**
 * @public
 * Hook to select a value from the editor state.
 * @example
 * Pass a selector as the second argument
 * ```tsx
 * import { useEditorSelector } from '@portabletext/editor'
 *
 * function MyComponent(editor) {
 *  const value = useEditorSelector(editor, selector)
 * }
 * ```
 * @example
 * Pass an inline selector as the second argument.
 * In this case, use the editor context to obtain the schema.
 * ```tsx
 * import { useEditorSelector } from '@portabletext/editor'
 *
 * function MyComponent(editor) {
 *  const schema = useEditorSelector(editor, (snapshot) => snapshot.context.schema)
 * }
 * ```
 * @group Hooks
 */
declare function useEditorSelector<TSelected>(editor: Editor, selector: EditorSelector<TSelected>, compare?: (a: TSelected, b: TSelected) => boolean): TSelected;
/**
 * @deprecated Use `useEditor` to get the current editor instance.
 * @public
 * Get the current editor object from the React context.
 */
declare const usePortableTextEditor: () => PortableTextEditor;
/**
 * @deprecated Use `useEditorSelector` to get the current editor selection.
 * @public
 * Get the current editor selection from the React context.
 */
declare const usePortableTextEditorSelection: () => EditorSelection;
/**
 * @public
 */
declare const defaultKeyGenerator: () => string;
/**
 * @public
 * Get the current editor context from the `EditorProvider`.
 * Must be used inside the `EditorProvider` component.
 * @returns The current editor object.
 * @example
 * ```tsx
 * import { useEditor } from '@portabletext/editor'
 *
 * function MyComponent() {
 *  const editor = useEditor()
 * }
 * ```
 * @group Hooks
 */
declare function useEditor(): Editor;
/**
 * An identity helper in the `defineSchema`/`defineDecorator` tradition:
 * contextual typing and autocomplete for a `Decoration` literal without
 * annotating it yourself. Accepts every member of the `Decoration`
 * union. Unrelated to `defineDecorator`, which defines a schema mark
 * like `strong`; a `Decoration` is an ephemeral visual layer entry for
 * `editor.registerDecorations`.
 * @beta
 */
declare function defineDecoration(decoration: Decoration): Decoration;
/**
 * @public
 */
type BlockOffset = {
  path: BlockPath;
  offset: number;
};
type EditorPriority = {
  id: string;
  name?: string;
  reference?: {
    priority: EditorPriority;
    importance: 'higher' | 'lower';
  };
};
type BehaviorConfig = {
  behavior: Behavior;
  priority: EditorPriority;
};
/**
 * @public
 */
type PatchesEvent = {
  type: 'patches';
  patches: Array<Patch>;
  snapshot: Array<PortableTextBlock> | undefined;
};
/**
 * @public
 */
type ExternalEditorEvent = {
  type: 'update readOnly';
  readOnly: boolean;
} | PatchesEvent;
type InternalPatchEvent = NamespaceEvent<PatchEvent, 'internal'> & {
  operationId?: string;
  value: Array<PortableTextBlock>;
};
/**
 * @internal
 */
type EditorActor = ActorRefFrom<typeof editorMachine>;
/**
 * @internal
 */
declare const editorMachine: import("xstate").StateMachine<{
  behaviors: Set<BehaviorConfig>;
  behaviorsSorted: boolean;
  initialConverters: Array<Converter>;
  keyGenerator: () => string;
  pendingEvents: Array<InternalPatchEvent | MutationEvent>;
  pendingIncomingPatchesEvents: Array<PatchesEvent>;
  pendingRegistrations: Array<RegistrableNode>;
  schema: EditorSchema;
  initialReadOnly: boolean;
  initialValue: Array<PortableTextBlock> | undefined;
  internalDrag?: {
    origin: Pick<EventPosition, 'selection'>;
  };
  dragGhost?: HTMLElement;
  editorEngine?: PortableTextEditorEngine;
}, MutationEvent | PatchesEvent | {
  type: 'update readOnly';
  readOnly: boolean;
} | {
  type: 'add behavior';
  behaviorConfig: BehaviorConfig;
} | {
  type: 'remove behavior';
  behaviorConfig: BehaviorConfig;
} | {
  type: 'blur';
  editor: PortableTextEditorEngine;
} | {
  type: 'focus';
  editor: PortableTextEditorEngine;
} | {
  type: 'update selection';
  selection: EditorSelection;
} | {
  type: 'done syncing value';
} | {
  type: 'syncing value';
} | {
  type: 'behavior event';
  behaviorEvent: BehaviorEvent;
  editor: PortableTextEditorEngine;
  nativeEvent?: {
    preventDefault: () => void;
  };
} | {
  type: 'set drag ghost';
  ghost: HTMLElement;
} | {
  type: 'dragstart';
  ghost?: HTMLElement;
  origin: Pick<EventPosition, 'selection'>;
} | {
  type: 'dragend';
} | {
  type: 'drop';
} | {
  type: 'register';
  node: RegistrableNode;
} | {
  type: 'unregister';
  node: RegistrableNode;
} | {
  type: 'add editor engine';
  editor: PortableTextEditorEngine;
} | InternalPatchEvent, {}, never, {
  type: "add behavior to context";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "add editor engine to context";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "attach maps to editor engine";
  params: unknown;
} | {
  type: "clear pending events";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "clear pending incoming patches";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "defer event";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "defer incoming patches";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "discard all pending events";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "discard conflicting pending patches";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "emit editable";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "emit mutation event";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "emit patch event";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "emit pending events";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "emit pending incoming patches";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "emit read only";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "emit ready";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "handle behavior event";
  params: unknown;
} | {
  type: "handle blur";
  params: unknown;
} | {
  type: "handle focus";
  params: unknown;
} | {
  type: "register";
  params: unknown;
} | {
  type: "remove behavior from context";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "sort behaviors";
  params: import("xstate").NonReducibleUnknown;
} | {
  type: "unregister";
  params: unknown;
}, {
  type: "engine is busy";
  params: unknown;
} | {
  type: "engine is normalizing node";
  params: unknown;
}, never, {
  "edit mode": {
    editable: "dragging internally" | "idle" | {
      focusing: "busy" | "checking if busy";
    };
  } | {
    "read only": "determine initial edit mode" | "read only";
  };
  setup: "setting up" | {
    "set up": {
      "value sync": "idle" | "syncing value";
      writing: "dirty" | {
        pristine: "idle";
      };
    };
  };
}, "dragging internally", {
  converters?: Array<Converter>;
  keyGenerator: () => string;
  readOnly?: boolean;
  schema: EditorSchema;
  initialValue?: Array<PortableTextBlock>;
}, import("xstate").NonReducibleUnknown, MutationEvent | PatchesEvent | {
  type: 'blurred';
  event: import("react").FocusEvent<HTMLDivElement, Element>;
} | {
  type: 'editable';
} | {
  type: 'focused';
  event: import("react").FocusEvent<HTMLDivElement, Element>;
} | {
  type: 'invalid value';
  resolution: InvalidValueResolution | null;
  value: Array<PortableTextBlock> | undefined;
} | {
  type: 'operation';
  operation: Operation;
  origin: 'local' | 'remote';
} | {
  type: 'read only';
} | {
  type: 'ready';
} | {
  type: 'selection';
  selection: EditorSelection;
} | {
  type: 'value changed';
  value: Array<PortableTextBlock> | undefined;
} | InternalPatchEvent, import("xstate").MetaObject, {
  id: "editor";
  states: {
    readonly 'edit mode': {
      states: {
        readonly 'read only': {
          states: {
            readonly 'determine initial edit mode': {};
            readonly 'read only': {};
          };
        };
        readonly editable: {
          states: {
            readonly idle: {};
            readonly focusing: {
              states: {
                readonly 'checking if busy': {};
                readonly busy: {};
              };
            };
            readonly 'dragging internally': {};
          };
        };
      };
    };
    readonly setup: {
      states: {
        readonly 'setting up': {};
        readonly 'set up': {
          states: {
            readonly 'value sync': {
              states: {
                readonly idle: {};
                readonly 'syncing value': {};
              };
            };
            readonly writing: {
              states: {
                readonly pristine: {
                  states: {
                    readonly idle: {};
                  };
                };
                readonly dirty: {};
              };
            };
          };
        };
      };
    };
  };
}, import("xstate").MetaObject>;
type EventPosition = {
  block: 'start' | 'end';
  /**
   * Did the event originate from the editor root DOM node itself, rather than
   * from a block inside the editor?
   */
  isEditor: boolean;
  /**
   * Did the event originate from an editable container's DOM node itself (for
   * example a code block or a table cell), rather than from a block inside the
   * container?
   */
  isContainer: boolean;
  selection: NonNullable<EditorSelection>;
};
type TextBlockWithOptionalKey = Omit<PortableTextTextBlock, '_key'> & {
  _key?: PortableTextTextBlock['_key'];
};
type ObjectBlockWithOptionalKey = Omit<PortableTextObject, '_key'> & {
  _key?: PortableTextObject['_key'];
};
type BlockWithOptionalKey = TextBlockWithOptionalKey | ObjectBlockWithOptionalKey;
type SpanWithOptionalKey = Omit<PortableTextSpan, '_key'> & {
  _key?: PortableTextSpan['_key'];
};
type ChildWithOptionalKey = SpanWithOptionalKey | ObjectBlockWithOptionalKey;
/**
 * @public
 */
type BehaviorEvent = SyntheticBehaviorEvent | NativeBehaviorEvent | CustomBehaviorEvent;
type BehaviorEventTypeNamespace = SyntheticBehaviorEventNamespace | NativeBehaviorEventNamespace | CustomBehaviorEventNamespace;
type NamespacedBehaviorEventType<TNamespace extends BehaviorEventTypeNamespace | ''> = TNamespace extends '' ? BehaviorEvent['type'] : Extract<BehaviorEvent['type'], TNamespace | `${TNamespace}.${string}`>;
/**************************************
 * External events
 **************************************/
type ExternalBehaviorEventNamespace = 'blur' | 'focus' | 'insert';
type ExternalBehaviorEventType<TNamespace extends ExternalBehaviorEventNamespace, TType extends string = ''> = TType extends '' ? `${TNamespace}` : `${TNamespace}.${TType}`;
type ExternalBehaviorEvent = {
  type: ExternalBehaviorEventType<'blur'>;
} | {
  type: ExternalBehaviorEventType<'focus'>;
} | {
  type: ExternalBehaviorEventType<'insert', 'block object'>;
  placement: InsertPlacement;
  blockObject: {
    name: string;
    value?: {
      [prop: string]: unknown;
    };
  };
} | BehaviorEvent;
/**************************************
 * Synthetic events
 **************************************/
declare const syntheticBehaviorEventTypes: readonly ['annotation.add', 'annotation.remove', 'block.set', 'block.unset', 'child.set', 'child.unset', 'decorator.add', 'decorator.remove', 'delete', 'history.redo', 'history.undo', 'insert', 'insert.block', 'insert.child', 'insert.text', 'move.backward', 'move.forward', 'remove.text', 'select', 'set', 'unset'];
type SyntheticBehaviorEventType = (typeof syntheticBehaviorEventTypes)[number] | (typeof abstractBehaviorEventTypes)[number];
type SyntheticBehaviorEventNamespace = ExtractNamespace<SyntheticBehaviorEventType>;
/**
 * @public
 */
type SyntheticBehaviorEvent = {
  type: StrictExtract<SyntheticBehaviorEventType, 'annotation.add'>;
  annotation: {
    name: string;
    _key?: string;
    value: {
      [prop: string]: unknown;
    };
  };
  at?: NonNullable<EditorSelection>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'annotation.remove'>;
  annotation: {
    name: string;
  };
  at?: NonNullable<EditorSelection>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'block.set'>;
  at: BlockPath;
  props: Record<string, unknown>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'block.unset'>;
  at: BlockPath;
  props: Array<string>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'child.set'>;
  at: ChildPath;
  props: {
    [prop: string]: unknown;
  };
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'child.unset'>;
  at: ChildPath;
  props: Array<string>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'decorator.add'>;
  decorator: string;
  at?: NonNullable<EditorSelection>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'decorator.remove'>;
  decorator: string;
  at?: NonNullable<EditorSelection>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'delete'>;
  at?: NonNullable<EditorSelection>;
  /**
   * Defaults to forward deletion.
   */
  direction?: 'backward' | 'forward';
  /**
   * Defaults to character deletion.
   */
  unit?: 'character' | 'word' | 'line' | 'block' | 'child';
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'history.redo'>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'history.undo'>;
} | {
  /**
   * @alpha
   *
   * Primitive: insert a node into an array.
   *
   * The last segment of `at` resolves the insertion point:
   * - A keyed `{_key}` segment inserts relative to that sibling.
   * - A numeric index inserts relative to that slot.
   *
   * `position` ('before' or 'after') is always meaningful: `before: [2]`
   * inserts at index 2, `after: [2]` inserts at index 3.
   *
   * @example
   * ```ts
   * raise({
   *   type: 'insert',
   *   at: [{_key: 'list'}, 'items', {_key: 'item3'}],
   *   value: newItem,
   *   position: 'after',
   * })
   * ```
   */
  type: StrictExtract<SyntheticBehaviorEventType, 'insert'>;
  at: Path;
  value: PortableTextTextBlock | PortableTextObject | PortableTextSpan;
  position: 'before' | 'after';
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'insert.block'>;
  block: BlockWithOptionalKey;
  placement: InsertPlacement;
  select?: 'start' | 'end' | 'none';
  at?: NonNullable<EditorSelection>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'insert.child'>;
  child: ChildWithOptionalKey;
} | {
  /**
   * Inserts text into a span.
   *
   * Without `at`/`offset`, text is inserted at the current caret position.
   * This is the form used by typing handlers.
   *
   * @alpha
   * With `at` and `offset`, text is inserted at the explicit position.
   * Recommended for plugin behaviors and collaborative-edit contexts.
   *
   * @example
   * ```ts
   * // Caret form
   * raise({type: 'insert.text', text: 'x'})
   *
   * // Primitive form (@alpha)
   * raise({
   *   type: 'insert.text',
   *   at: [{_key: 'b1'}, 'children', {_key: 's1'}],
   *   offset: 5,
   *   text: 'world',
   * })
   * ```
   */
  type: StrictExtract<SyntheticBehaviorEventType, 'insert.text'>;
  at?: Path;
  offset?: number;
  text: string;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'move.backward'>;
  distance: number;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'move.forward'>;
  distance: number;
} | {
  /**
   * @alpha
   *
   * Primitive: remove text from a span at the given offset.
   *
   * The `text` field carries the exact text being removed (matches the
   * apply-layer shape so the inverse can be computed without re-reading
   * the span).
   *
   * Recommended for collaborative-edit contexts (concurrent edits compose
   * cleanly under operational transform).
   *
   * @example
   * ```ts
   * raise({
   *   type: 'remove.text',
   *   at: [{_key: 'b1'}, 'children', {_key: 's1'}],
   *   offset: 5,
   *   text: 'world',
   * })
   * ```
   */
  type: StrictExtract<SyntheticBehaviorEventType, 'remove.text'>;
  at: Path;
  offset: number;
  text: string;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'select'>;
  at: EditorSelection;
} | {
  /**
   * @alpha
   *
   * Primitive: set a property on a node, or replace a node wholesale.
   *
   * The last segment of `at` is the property name (a string) for property
   * updates, OR a keyed/indexed segment for full-node replacement.
   *
   * Note: `set` on span text (`{at: [...spanPath, 'text'], value: '...'}`)
   * is legal but not recommended in collaborative-edit contexts. Use
   * `insert.text` and `remove.text` for text edits that compose under
   * operational transform.
   *
   * @example
   * ```ts
   * // Set a block's style
   * raise({type: 'set', at: [{_key: 'b1'}, 'style'], value: 'h1'})
   *
   * // Replace a block wholesale
   * raise({type: 'set', at: [{_key: 'b1'}], value: newBlock})
   * ```
   */
  type: StrictExtract<SyntheticBehaviorEventType, 'set'>;
  at: Path;
  value: unknown;
} | {
  /**
   * @alpha
   *
   * Primitive: unset a property on an object, OR remove a node from an
   * array.
   *
   * When the last segment of `at` is a string, the property is removed.
   * When the last segment is a keyed `{_key}` segment or a numeric index,
   * the node at that array position is removed.
   *
   * @example
   * ```ts
   * // Remove a property
   * raise({type: 'unset', at: [{_key: 'b1'}, 'level']})
   *
   * // Remove a node from an array
   * raise({type: 'unset', at: [{_key: 'list'}, 'items', {_key: 'item3'}]})
   * ```
   */
  type: StrictExtract<SyntheticBehaviorEventType, 'unset'>;
  at: Path;
} | AbstractBehaviorEvent;
/**
 * @public
 */
type InsertPlacement = 'auto' | 'after' | 'before';
/**************************************
 * Abstract events
 **************************************/
declare const abstractBehaviorEventTypes: readonly ['annotation.set', 'annotation.toggle', 'decorator.toggle', 'delete.backward', 'delete.block', 'delete.child', 'delete.forward', 'delete.text', 'deserialize', 'deserialize.data', 'deserialization.success', 'deserialization.failure', 'insert.blocks', 'insert.break', 'insert.inline object', 'insert.soft break', 'insert.span', 'list item.add', 'list item.remove', 'list item.toggle', 'move.block', 'move.block down', 'move.block up', 'select.block', 'select.previous block', 'select.next block', 'serialize', 'serialize.data', 'serialization.success', 'serialization.failure', 'split', 'style.add', 'style.remove', 'style.toggle'];
type AbstractBehaviorEvent = {
  type: StrictExtract<SyntheticBehaviorEventType, 'annotation.set'>;
  at: AnnotationPath;
  props: Record<string, unknown>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'annotation.toggle'>;
  annotation: {
    name: string;
    value: {
      [prop: string]: unknown;
    };
  };
  at?: NonNullable<EditorSelection>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'decorator.toggle'>;
  decorator: string;
  at?: NonNullable<EditorSelection>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'delete.backward'>;
  unit: 'character' | 'word' | 'line' | 'block';
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'delete.block'>;
  at: BlockPath;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'delete.child'>;
  at: ChildPath;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'delete.forward'>;
  unit: 'character' | 'word' | 'line' | 'block';
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'delete.text'>;
  at: NonNullable<EditorSelection>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'deserialize'>;
  originEvent: PickFromUnion<NativeBehaviorEvent, 'type', 'drag.drop' | 'clipboard.paste'> | InputBehaviorEvent;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'deserialize.data'>;
  mimeType: MIMEType;
  data: string;
  originEvent: PickFromUnion<NativeBehaviorEvent, 'type', 'drag.drop' | 'clipboard.paste'> | InputBehaviorEvent;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'serialize'>;
  originEvent: PickFromUnion<NativeBehaviorEvent, 'type', 'clipboard.copy' | 'clipboard.cut' | 'drag.dragstart'>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'serialize.data'>;
  mimeType: MIMEType;
  originEvent: PickFromUnion<NativeBehaviorEvent, 'type', 'clipboard.copy' | 'clipboard.cut' | 'drag.dragstart'>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'deserialization.success'>;
  mimeType: MIMEType;
  data: Array<PortableTextBlock>;
  originEvent: PickFromUnion<NativeBehaviorEvent, 'type', 'drag.drop' | 'clipboard.paste'> | InputBehaviorEvent;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'deserialization.failure'>;
  mimeType: MIMEType;
  reason: string;
  originEvent: PickFromUnion<NativeBehaviorEvent, 'type', 'drag.drop' | 'clipboard.paste'> | InputBehaviorEvent;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'serialization.success'>;
  mimeType: MIMEType;
  data: string;
  originEvent: PickFromUnion<NativeBehaviorEvent, 'type', 'clipboard.copy' | 'clipboard.cut' | 'drag.dragstart'>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'serialization.failure'>;
  mimeType: MIMEType;
  reason: string;
  originEvent: PickFromUnion<NativeBehaviorEvent, 'type', 'clipboard.copy' | 'clipboard.cut' | 'drag.dragstart'>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'insert.blocks'>;
  blocks: Array<BlockWithOptionalKey>;
  placement: InsertPlacement;
  select?: 'start' | 'end' | 'none';
  at?: NonNullable<EditorSelection>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'insert.break'>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'insert.inline object'>;
  inlineObject: {
    name: string;
    value?: {
      [prop: string]: unknown;
    };
  };
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'insert.soft break'>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'insert.span'>;
  text: string;
  annotations?: Array<{
    name: string;
    value: {
      [prop: string]: unknown;
    };
  }>;
  decorators?: Array<string>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'list item.add'>;
  listItem: string;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'list item.remove'>;
  listItem: string;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'list item.toggle'>;
  listItem: string;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'move.block'>;
  at: BlockPath;
  to: BlockPath;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'move.block down'>;
  at: BlockPath;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'move.block up'>;
  at: BlockPath;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'select.block'>;
  at: BlockPath;
  select?: 'start' | 'end';
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'select.previous block'>;
  select?: 'start' | 'end';
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'select.next block'>;
  select?: 'start' | 'end';
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'split'>;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'style.add'>;
  style: string;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'style.remove'>;
  style: string;
} | {
  type: StrictExtract<SyntheticBehaviorEventType, 'style.toggle'>;
  style: string;
};
/**************************************
 * Native events
 **************************************/
declare const nativeBehaviorEventTypes: readonly ['clipboard.copy', 'clipboard.cut', 'clipboard.paste', 'drag.dragstart', 'drag.drag', 'drag.dragend', 'drag.dragenter', 'drag.dragover', 'drag.dragleave', 'drag.drop', 'input.*', 'keyboard.keydown', 'keyboard.keyup', 'mouse.click'];
type NativeBehaviorEventType = (typeof nativeBehaviorEventTypes)[number];
type NativeBehaviorEventNamespace = ExtractNamespace<NativeBehaviorEventType>;
/**
 * @public
 */
type NativeBehaviorEvent = ClipboardBehaviorEvent | DragBehaviorEvent | InputBehaviorEvent | KeyboardBehaviorEvent | MouseBehaviorEvent;
type ClipboardBehaviorEvent = {
  type: StrictExtract<NativeBehaviorEventType, 'clipboard.copy'>;
  originEvent: {
    dataTransfer: DataTransfer;
  };
  position: Pick<EventPosition, 'selection'>;
} | {
  type: StrictExtract<NativeBehaviorEventType, 'clipboard.cut'>;
  originEvent: {
    dataTransfer: DataTransfer;
  };
  position: Pick<EventPosition, 'selection'>;
} | {
  type: StrictExtract<NativeBehaviorEventType, 'clipboard.paste'>;
  originEvent: {
    dataTransfer: DataTransfer;
  };
  position: Pick<EventPosition, 'selection'>;
};
type DragBehaviorEvent = {
  type: StrictExtract<NativeBehaviorEventType, 'drag.dragstart'>;
  originEvent: {
    clientX: number;
    clientY: number;
    dataTransfer: DataTransfer;
  };
  position: Pick<EventPosition, 'selection'>;
} | {
  type: StrictExtract<NativeBehaviorEventType, 'drag.drag'>;
  originEvent: {
    dataTransfer: DataTransfer;
  };
} | {
  type: StrictExtract<NativeBehaviorEventType, 'drag.dragend'>;
  originEvent: {
    dataTransfer: DataTransfer;
  };
} | {
  type: StrictExtract<NativeBehaviorEventType, 'drag.dragenter'>;
  originEvent: {
    dataTransfer: DataTransfer;
  };
  position: EventPosition;
} | {
  type: StrictExtract<NativeBehaviorEventType, 'drag.dragover'>;
  originEvent: {
    dataTransfer: DataTransfer;
  };
  dragOrigin?: Pick<EventPosition, 'selection'>;
  position: EventPosition;
} | {
  type: StrictExtract<NativeBehaviorEventType, 'drag.drop'>;
  originEvent: {
    dataTransfer: DataTransfer;
  };
  dragOrigin?: Pick<EventPosition, 'selection'>;
  position: EventPosition;
} | {
  type: StrictExtract<NativeBehaviorEventType, 'drag.dragleave'>;
  originEvent: {
    dataTransfer: DataTransfer;
  };
};
/**
 * Used to represent native InputEvents that hold a DataTransfer object.
 *
 * These can either be one of:
 *
 * - insertFromPaste
 * - insertFromPasteAsQuotation
 * - insertFromDrop
 * - insertReplacementText
 * - insertFromYank
 */
type InputBehaviorEvent = {
  type: StrictExtract<NativeBehaviorEventType, 'input.*'>;
  originEvent: {
    dataTransfer: DataTransfer;
  };
};
type KeyboardBehaviorEvent = {
  type: StrictExtract<NativeBehaviorEventType, 'keyboard.keydown'>;
  originEvent: Pick<KeyboardEvent, 'key' | 'code' | 'altKey' | 'ctrlKey' | 'metaKey' | 'shiftKey'>;
} | {
  type: StrictExtract<NativeBehaviorEventType, 'keyboard.keyup'>;
  originEvent: Pick<KeyboardEvent, 'key' | 'code' | 'altKey' | 'ctrlKey' | 'metaKey' | 'shiftKey'>;
};
type MouseBehaviorEvent = {
  type: StrictExtract<NativeBehaviorEventType, 'mouse.click'>;
  position: EventPosition;
};
/**************************************
 * Custom events
 **************************************/
type CustomBehaviorEventNamespace = 'custom';
type CustomBehaviorEventType<TNamespace extends CustomBehaviorEventNamespace, TType extends string = ''> = TType extends '' ? `${TNamespace}` : `${TNamespace}.${TType}`;
/**
 * @public
 */
type CustomBehaviorEvent<TPayload extends Record<string, unknown> = Record<string, unknown>, TType extends string = string, TInternalType extends CustomBehaviorEventType<'custom', TType> = CustomBehaviorEventType<'custom', TType>> = {
  type: TInternalType;
} & TPayload;
/**************************************
 * Resolve behavior event
 **************************************/
type ResolveBehaviorEvent<TBehaviorEventType extends '*' | `${BehaviorEventTypeNamespace}.*` | BehaviorEvent['type'], TPayload extends Record<string, unknown> = Record<string, unknown>> = TBehaviorEventType extends '*' ? BehaviorEvent : TBehaviorEventType extends `${infer TNamespace}.*` ? TNamespace extends BehaviorEventTypeNamespace ? PickFromUnion<BehaviorEvent, 'type', NamespacedBehaviorEventType<TNamespace>> : never : TBehaviorEventType extends `custom.${infer TType}` ? CustomBehaviorEvent<TPayload, TType> : TBehaviorEventType extends BehaviorEvent['type'] ? PickFromUnion<BehaviorEvent, 'type', TBehaviorEventType> : never;
type ExtractNamespace<TType extends string> = TType extends `${infer Namespace}.${string}` ? Namespace : TType;
type EditorDom = {
  getBlockNodes: (snapshot: EditorSnapshot) => Array<Node>;
  getChildNodes: (snapshot: EditorSnapshot) => Array<Node>;
  getEditorElement: () => Element | undefined;
  /**
   * The bounding rect of the snapshot's selection. A collapsed selection gives
   * a caret rect.
   */
  getSelectionRect: (snapshot: EditorSnapshot) => DOMRect | null;
  /**
   * Resolves viewport (client) coordinates to the editor point where a click
   * at those coordinates would place the caret. The browser snaps to the
   * nearest position within the element at the coordinates. Returns `null`
   * when the coordinates don't resolve to a position inside the editor's
   * content.
   */
  getPointAtCoordinates: (coordinates: {
    x: number;
    y: number;
  }) => EditorSelectionPoint | null;
  getStartBlockElement: (snapshot: EditorSnapshot) => Element | null;
  getEndBlockElement: (snapshot: EditorSnapshot) => Element | null;
  /**
   * Let the Editor set the drag ghost. This is to be sure that it will get
   * properly removed again when the drag ends.
   */
  setDragGhost: ({ event, ghost }: {
    event: PickFromUnion<BehaviorEvent, 'type', 'drag.dragstart'>;
    ghost: {
      element: HTMLElement;
      x: number;
      y: number;
    };
  }) => void;
};
/**
 * @public
 */
type BehaviorAction = {
  type: 'execute';
  event: SyntheticBehaviorEvent;
} | {
  type: 'forward';
  event: NativeBehaviorEvent | SyntheticBehaviorEvent | CustomBehaviorEvent;
} | {
  type: 'raise';
  event: SyntheticBehaviorEvent | CustomBehaviorEvent;
} | {
  type: 'effect';
  effect: (payload: {
    /**
     * Send a Behavior Event back into the Editor.
     *
     * @example
     * ```ts
     * defineBehavior({
     *   on: '...',
     *   actions: [
     *     () => [
     *       effect(({send}) => {
     *         doSomethingAsync()
     *           .then(() => {
     *             send({
     *               type: '...',
     *             })
     *           })
     *       })
     *     ],
     *   ],
     * })
     * ```
     */
    send: (event: ExternalBehaviorEvent) => void;
  }) => void;
};
/**
 * Directly executes an event, bypassing all Behavior matching.
 *
 * Use `execute` when you want to perform an action without triggering any
 * Behaviors. The event is executed immediately as a direct operation.
 *
 * @example
 * ```ts
 * defineBehavior({
 *   on: 'insert.text',
 *   guard: ({event}) => event.text === 'a',
 *   actions: [() => [execute({type: 'insert.text', text: 'b'})]],
 * })
 * ```
 *
 * @public
 */
declare function execute(event: SyntheticBehaviorEvent): PickFromUnion<BehaviorAction, 'type', 'execute'>;
/**
 * Forwards an event to the next Behavior(s) in the current chain.
 *
 * Use `forward` to pass an event to succeeding Behaviors without starting a
 * fresh lookup. This is useful for intercepting events, performing side
 * effects, and then letting the default handling continue.
 *
 * **Key rule:** When forwarding to a different event type, only Behaviors that
 * were already in the remaining chain AND match the new type will run. This
 * means cross-type `forward` is mostly useful for falling through to default
 * Behaviors, not for triggering user-defined Behaviors of a different type.
 *
 * To trigger all Behaviors for a different event type, use {@link raise}
 * instead.
 *
 * @example
 * ```ts
 * // Intercept and forward same event type
 * defineBehavior({
 *   on: 'insert.text',
 *   actions: [({event}) => [effect(logEvent), forward(event)]],
 * })
 *
 * // Forward to default handling of different event type
 * defineBehavior({
 *   on: 'clipboard.paste',
 *   actions: [
 *     ({event}) => {
 *       const text = event.originEvent.dataTransfer?.getData('text/plain')
 *       return text ? [forward({type: 'insert.text', text})] : []
 *     },
 *   ],
 * })
 * ```
 *
 * @public
 */
declare function forward(event: NativeBehaviorEvent | SyntheticBehaviorEvent | CustomBehaviorEvent): PickFromUnion<BehaviorAction, 'type', 'forward'>;
/**
 * Raises an event, triggering a fresh lookup of all Behaviors.
 *
 * Use `raise` when you want to trigger an event "from scratch", including all
 * Behaviors that match the event type. This is the appropriate action when you
 * want to trigger Behaviors for a different event type.
 *
 * If no Behavior matches the raised event, synthetic events will fall through
 * to their default operation.
 *
 * @example
 * ```ts
 * // Raise a custom event that triggers other Behaviors
 * defineBehavior({
 *   on: 'insert.text',
 *   guard: ({event}) => event.text === 'a',
 *   actions: [() => [raise({type: 'custom.specialInsert'})]],
 * })
 *
 * // Raise a different event type (fresh lookup includes all Behaviors)
 * defineBehavior({
 *   on: 'clipboard.paste',
 *   actions: [
 *     ({event}) => {
 *       const text = event.originEvent.dataTransfer?.getData('text/plain')
 *       return text ? [raise({type: 'insert.text', text})] : []
 *     },
 *   ],
 * })
 * ```
 *
 * @public
 */
declare function raise$1(event: SyntheticBehaviorEvent | CustomBehaviorEvent): PickFromUnion<BehaviorAction, 'type', 'raise'>;
/**
 * Performs a side effect.
 *
 * Use `effect` for logging, analytics, async operations, or other side effects.
 *
 * **Note:** Using `effect` alone (without `forward`) will stop event
 * propagation. To perform a side effect while allowing the default Behavior
 * to continue, combine `effect` with `forward`.
 *
 * The effect callback receives a `send` function that can be used to send
 * events back to the editor asynchronously.
 *
 * @example
 * ```ts
 * // Log events while preserving default Behavior
 * defineBehavior({
 *   on: 'insert.text',
 *   actions: [({event}) => [effect(() => console.log(event)), forward(event)]],
 * })
 *
 * // Effect alone stops propagation (native event is cancelled)
 * defineBehavior({
 *   on: 'keyboard.keydown',
 *   actions: [() => [effect(() => console.log('key pressed'))]],
 * })
 *
 * // Async effect that sends an event later
 * defineBehavior({
 *   on: 'custom.save',
 *   actions: [
 *     () => [
 *       effect(async ({send}) => {
 *         await saveDocument()
 *         send({type: 'custom.saved'})
 *       }),
 *     ],
 *   ],
 * })
 * ```
 *
 * @public
 */
declare function effect(effect: PickFromUnion<BehaviorAction, 'type', 'effect'>['effect']): PickFromUnion<BehaviorAction, 'type', 'effect'>;
/**
 * @public
 */
type BehaviorActionSet<TBehaviorEvent, TGuardResponse> = (payload: {
  snapshot: EditorSnapshot;
  event: TBehaviorEvent;
  dom: EditorDom;
}, guardResponse: TGuardResponse) => Array<BehaviorAction>;
export { defineBehavior as $, SpanRender as $t, PortableTextSpan$1 as A, Containers as At, usePortableTextEditorSelection as B, BlockObjectRender as Bt, ListDefinition as C, PortableTextEditable as Ct, PortableTextBlock$1 as D, TraversalSnapshot as Dt, Patch$1 as E, PortableTextEditor as Et, defineSchema as F, RegisteredSpan as Ft, EditorProviderProps as G, Decorator as Gt, EditorSelector as H, Container as Ht, BlockOffset as I, Annotation as It, EditorEvent as J, InlineObject as Jt, Editor as K, DecoratorRender as Kt, defineDecoration as L, AnnotationRender as Lt, SchemaDefinition$1 as M, RegisteredContainer as Mt, StyleDefinition as N, RegisteredInlineObject as Nt, PortableTextChild$1 as O, Node$1 as Ot, StyleSchemaType as P, RegisteredPositional as Pt, Behavior as Q, Span as Qt, useEditor as R, AnnotationRenderProps as Rt, InlineObjectSchemaType as S, ScrollSelectionIntoViewFunction as St, OfDefinition$1 as T, HotkeyOptions as Tt, useEditorSelector as U, ContainerRender as Ut, usePortableTextEditor as V, BlockObjectRenderProps as Vt, EditorProvider as W, ContainerRenderProps as Wt, MutationEvent as X, InlineObjectRenderProps as Xt, EditorEmittedEvent as Y, InlineObjectRender as Yt, Operation as Z, RegistrableNode as Zt, BlockObjectSchemaType as _, PasteData as _t, forward as a, defineBlockObject as an, DecorationMapping as at, FieldDefinition$1 as b, RenderEditableFunction as bt, CustomBehaviorEvent as c, defineInlineObject as cn, DecorationRenderProps as ct, SyntheticBehaviorEvent as d, AnnotationPath as dn, EditorSelectionPoint as dt, SpanRenderProps as en, BehaviorGuard as et, PatchesEvent as f, BlockPath as fn, InvalidValueResolution as ft, BlockObjectDefinition as g, PathSegment as gn, OnPasteResultOrPromise as gt, BaseDefinition as h, Path as hn, OnPasteResult as ht, execute as i, defineAnnotation as in, Decoration as it, PortableTextTextBlock$1 as j, RegisteredBlockObject as jt, PortableTextObject$1 as k, EditorSchema as kt, InsertPlacement as l, defineSpan as ln, EditableAPIDeleteOptions as lt, AnnotationSchemaType as m, KeyedSegment as mn, OnPasteFn as mt, BehaviorActionSet as n, TextBlockRender as nn, EditorSnapshot as nt, raise$1 as o, defineContainer as on, DecorationPosition as ot, AnnotationDefinition as p, ChildPath as pn, OnCopyFn as pt, EditorConfig as q, DecoratorRenderProps as qt, effect as r, TextBlockRenderProps as rn, AddedAnnotationPaths as rt, BehaviorEvent as s, defineDecorator as sn, DecorationRegistration as st, BehaviorAction as t, TextBlock as tn, EditorContext as tt, NativeBehaviorEvent as u, defineTextBlock as un, EditorSelection as ut, DecoratorDefinition as v, RangeDecoration as vt, ListSchemaType as w, PortableTextEditableProps as wt, InlineObjectDefinition as x, RenderPlaceholderFunction as xt, DecoratorSchemaType as y, RangeDecorationOnMovedDetails as yt, defaultKeyGenerator as z, BlockObject as zt };
//# sourceMappingURL=behavior.types.action-CJHHYRYc.d.ts.map