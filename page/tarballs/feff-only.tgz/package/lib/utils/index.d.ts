import { Dt as TraversalSnapshot, I as BlockOffset, dt as EditorSelectionPoint, fn as BlockPath, gn as PathSegment, hn as Path, mn as KeyedSegment, tt as EditorContext, ut as EditorSelection } from "../behavior.types.action-CJHHYRYc.js";
import { PortableTextBlock, PortableTextTextBlock, isSpan, isTextBlock } from "@portabletext/schema";
/**
 * @public
 */
declare function blockOffsetToSpanSelectionPoint({ snapshot, blockOffset, direction }: {
  snapshot: TraversalSnapshot;
  blockOffset: BlockOffset;
  direction: 'forward' | 'backward';
}): {
  path: PathSegment[];
  offset: number;
} | undefined;
/**
 * @public
 */
declare function spanSelectionPointToBlockOffset({ snapshot, selectionPoint }: {
  snapshot: TraversalSnapshot;
  selectionPoint: EditorSelectionPoint;
}): BlockOffset | undefined;
/**
 * @public
 */
declare function blockOffsetsToSelection({ snapshot, offsets, backward }: {
  snapshot: TraversalSnapshot;
  offsets: {
    anchor: BlockOffset;
    focus: BlockOffset;
  };
  backward?: boolean;
}): EditorSelection;
/**
 * @public
 */
declare function childSelectionPointToBlockOffset({ snapshot, selectionPoint }: {
  snapshot: TraversalSnapshot;
  selectionPoint: EditorSelectionPoint;
}): BlockOffset | undefined;
/**
 * @public
 */
declare function getBlockEndPoint({ context, block }: {
  context: Pick<EditorContext, 'schema'>;
  block: {
    node: PortableTextBlock;
    path: BlockPath;
  };
}): EditorSelectionPoint;
/**
 * @public
 */
declare function getBlockStartPoint({ context, block }: {
  context: Pick<EditorContext, 'schema'>;
  block: {
    node: PortableTextBlock;
    path: BlockPath;
  };
}): EditorSelectionPoint;
/**
 * @public
 */
declare function getSelectionEndPoint<TEditorSelection extends NonNullable<EditorSelection> | null, TEditorSelectionPoint extends EditorSelectionPoint | null = TEditorSelection extends NonNullable<EditorSelection> ? EditorSelectionPoint : null>(selection: TEditorSelection): TEditorSelectionPoint;
/**
 * @public
 */
declare function getSelectionStartPoint<TEditorSelection extends NonNullable<EditorSelection> | null, TEditorSelectionPoint extends EditorSelectionPoint | null = TEditorSelection extends NonNullable<EditorSelection> ? EditorSelectionPoint : null>(selection: TEditorSelection): TEditorSelectionPoint;
/**
 * @public
 */
declare function getTextBlockText(block: PortableTextTextBlock): string;
/**
 * @public
 */
declare function isEmptyTextBlock(context: Pick<EditorContext, 'schema'>, block: PortableTextBlock | unknown): boolean;
/**
 * @public
 */
declare function isEqualPaths(a: Path, b: Path): boolean;
/**
 * @public
 */
declare function isEqualSelectionPoints(a: EditorSelectionPoint, b: EditorSelectionPoint): boolean;
/**
 * @public
 */
declare function isEqualSelections(a: EditorSelection, b: EditorSelection): boolean;
/**
 * @public
 */
declare function isKeyedSegment(segment: unknown): segment is KeyedSegment;
/**
 * @public
 */
declare function isSelectionCollapsed(selection: EditorSelection): boolean;
/**
 * @beta
 */
declare function mergeTextBlocks({ context, targetBlock, incomingBlock }: {
  context: Pick<EditorContext, 'keyGenerator' | 'schema'>;
  targetBlock: PortableTextTextBlock;
  incomingBlock: PortableTextTextBlock;
}): PortableTextTextBlock<import("@portabletext/schema").PortableTextObject | import("@portabletext/schema").PortableTextSpan>;
/**
 * @public
 */
declare function reverseSelection<TEditorSelection extends NonNullable<EditorSelection> | null>(selection: TEditorSelection): TEditorSelection;
/**
 * @public
 */
declare function sliceBlocks({ context, blocks }: {
  context: Pick<EditorContext, 'schema' | 'selection'> & {
    keyGenerator?: () => string;
  };
  blocks: Array<PortableTextBlock>;
}): Array<PortableTextBlock>;
export { blockOffsetToSpanSelectionPoint, blockOffsetsToSelection, childSelectionPointToBlockOffset, getBlockEndPoint, getBlockStartPoint, getSelectionEndPoint, getSelectionStartPoint, getTextBlockText, isEmptyTextBlock, isEqualPaths, isEqualSelectionPoints, isEqualSelections, isKeyedSegment, isSelectionCollapsed, isSpan, isTextBlock, mergeTextBlocks, reverseSelection, sliceBlocks, spanSelectionPointToBlockOffset };
//# sourceMappingURL=index.d.ts.map